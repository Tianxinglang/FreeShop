/* 
* @Author: cardqu
* @Date:   2015-11-26 10:32:57
* @Last Modified by:   cardqu
* @Last Modified time: 2015-12-28 15:32:49
*/

$(function(){
	//auto adaptation
	var calculate_size = function () {
	var BASE_FONT_SIZE = 100;
	var docEl = document.documentElement,
	clientWidth = docEl.clientWidth;
	if (!clientWidth) return;
	docEl.style.fontSize = BASE_FONT_SIZE * (clientWidth / 750) + 'px';
	};

	// Abort if browser does not support addEventListener
	if (document.addEventListener) {
	var resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize';
	window.addEventListener(resizeEvt, calculate_size, false);
	document.addEventListener('DOMContentLoaded', calculate_size, false);
	calculate_size();
	}
})
//var _hmt = _hmt || [];
//        (function() {
//          var hm = document.createElement("script");
//          hm.src = "//hm.baidu.com/hm.js?ea9bb58a625237ba9c49476478c8375d";
//          var s = document.getElementsByTagName("script")[0]; 
//          s.parentNode.insertBefore(hm, s);
//    })();