package com.wechat.sample;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;

public class WechatLogin {
	public static void main(String[] args) throws Exception {
		
		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod("http://localhost:8080/KaQuService/2.3/user/wechat/login.json");
		//参数
		NameValuePair[] postData = new NameValuePair[5];
		postData[0] = new NameValuePair("username","18201890943");
		postData[1] = new NameValuePair("password","bwN5u3z/mDaGOid7qeVLv69kcv2/s+i9+JxPBYkw+SjRIj6/+VgETEHKKqjRqBDHzCpgJoNCNSmawmvGO6WoTNlV7o+FVuO7gsWT66QnTDuiBX/F2LbzCd9tzbjX+fq6JAp9R7bYrP2wSnGk59ZGtbk6FkvP0kGS4mv3/s36Pos=");
		postData[2] = new NameValuePair("type","mobile");
		postData[3] = new NameValuePair("client_id","IOS");
		postData[4] = new NameValuePair("ky_app_id","");
		postMethod.setRequestBody(postData);
		try {
			httpClient.executeMethod(postMethod);
			String loginResult = postMethod.getResponseBodyAsString();
			//打印返回信息 
			System.out.println(loginResult);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
