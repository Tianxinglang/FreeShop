package com.freeshop.interceptor;

import java.util.ArrayList;
import java.util.List;

import com.freeshop.domain.table.T_Usr_Tokens;
import com.freeshop.repository.UsrTokenRepository;
import com.freeshop.utils.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 验证拦截
 * 
 * 增加用户操作后记录
 */
public class SecurityInterceptor implements HandlerInterceptor{
    private Logger log = LogManager.getLogger(SecurityInterceptor.class);
    private String url;//拦截之后跳转
	private static List<String> interceptorRegexs=new ArrayList<String>();//需要做签名认证的

	@Autowired
	private UsrTokenRepository usrTokenRepository;

	static{
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/user/register.json");
//		interceptorRegexs.add("/FreeShop/user/register.json");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/user/registergetcode.json");
//		interceptorRegexs.add("/FreeShop/user/registergetcode.json");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/user/findpsw.json");
//		interceptorRegexs.add("/FreeShop/user/findpsw.json");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/pointact/trade.json");
		//interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/hotels/group/\\d{3,4}/bind.json");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/user/login.json");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/user/login.json");
		interceptorRegexs.add("/FreeShop/admin/login.html");
//		interceptorRegexs.add("/FreeShop/\\d{1}.\\d{1}/coupon/user/collect.json");
	}

	@Value("${kaqu_secret}")
	private String appSecret;
	

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    	request.setAttribute("kaqu_response_time", System.nanoTime());
    	if(request.getMethod().equalsIgnoreCase(RequestMethod.POST.toString())){
    		if(StringUtils.isNotEmptyTrim(request.getHeader("Authorization"))){
    			String token = request.getHeader("Authorization").trim().substring("Bearer ".length());
    			T_Usr_Tokens ut = usrTokenRepository.getByToken(token);
    			if(ut==null){
    				log.error("服务器分发的授权令牌 非法   access_token="+token);
    				response.sendRedirect(request.getContextPath()+url);
    				return false;
    			}else{
    				request.setAttribute("u_id",ut.getU_id());
    			}
    		}
    		
    	}
    	
//    	//做签名认证
//		boolean needCheckSignFlag=false;//是否需要签名验证
//		String requri=request.getRequestURI();
//		if(StringUtils.isNotEmptyTrim(requri)){
//			for(String regex:interceptorRegexs){
//				if(requri.matches(regex)) {
//					needCheckSignFlag=true;
//					break;
//				}
//			}
//		}
//		
//		if(needCheckSignFlag)
//		{
//			  String t=request.getParameter("timestamp");
//	          long timestamp=Long.parseLong((t==null?"0":t));
//		      long currentTime=System.currentTimeMillis()/1000;
//		      boolean check= SignUtils.signVerify(appSecret, request);
//		      JSONObject json=new JSONObject();
//		  	  long time = new Date().getTime()/1000;
//		      json.accumulate("err_code", CommonError.UnknownError.code());
//		      json.accumulate("ts", time);
//		      log.info("请求需要验证接口为:"+requri);
//			
//		      if (!check) {
//			      json.accumulate("err_msg", CommonError.IllegalRequest);
//			      response.addHeader("Content-Type","application/json;charset=UTF-8");
//			      response.getWriter().write(json.toString());
//		          log.info("用户("+request.getAttribute("u_id")+"),"+CommonError.IllegalRequest);
//		          return false;
//		      }
//		      String tradetime = request.getParameter("tradetime");
//		      if(StringUtils.isEmpty(tradetime)){//非离线集点需要判断2次请求的间隔
//		    	  if(Math.abs(currentTime-timestamp)>30*60){
//		    		  json.accumulate("err_msg",CommonError.IllegalTimeError);
//		    		  response.addHeader("Content-Type","application/json;charset=UTF-8");
//		    		  response.getWriter().write(json.toString());
//		    		  log.info("用户("+request.getAttribute("u_id")+"),"+CommonError.IllegalTimeError);
//		    		  return false;
//		    	  }
//		      }
//		}
		
    	return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }


    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
    	try {
			//此处记录用户的行为
			
		} catch (Exception e) {
			log.error(e.getMessage());
		}
    }

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
