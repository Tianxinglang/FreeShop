package com.freeshop.service.helper;

import java.util.ArrayList;
import java.util.List;


/**
 * 名称辅助类
 * */
public class NameHelper {

    
    /**
     * 用户登录名称生成
     * */
    public static String getUserLoginName(List<String> user_logins,String nicename,String source){
    	return getNickname(user_logins,nicename,source);
    }
    
	/**
	 * 用户昵称生成
	 * */
	public static String getNickname(List<String> user_logins,String nicename,String source){
		String khsource1 = "";
		if(source!=null){
			khsource1 = "("+source+")";
		}else{
			khsource1 = "_1";
		}
		if(user_logins==null||user_logins.isEmpty()){
    		return nicename;
    	}
		if(user_logins.size()==1){
			String s = user_logins.get(0);
//			if(!nicename.equals(s)){
//				return nicename;
//			}
//			return nicename+khsource1;
			return s+khsource1;
		}
		if(user_logins.size()==2){
//			String s = nicename+khsource1;
//			if(!s.equals(user_logins.get(0))&&!s.equals(user_logins.get(1))){
//				return s;
//			}
		}
		String khsource = "";
		if(source!=null){
			khsource = "("+source+")";
		}
		int k = 0;
    	for(String s : user_logins){
    		String[] arr = s.substring(nicename.length()-1).split("_");
    		if(arr.length>1){
    			String a = arr[arr.length-1];
				try {
					int b = Integer.parseInt(a);
					if(b>k){
    					k=b;
    				}
				} catch (NumberFormatException e) {
				}
    		}
    	}
		return nicename+khsource+"_"+(k+1);
	}
	
	public static void main(String[] args) {
		List<String> ls = new ArrayList<String>();
		ls.add("eee(r)_2(r)");
		ls.add("eee(r)_3(r)");
		System.out.println(getNickname(ls, "eee", "r"));
	}
}
