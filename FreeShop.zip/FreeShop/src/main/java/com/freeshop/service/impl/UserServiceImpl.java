package com.freeshop.service.impl;

import com.freeshop.service.UserService;


//@Service
public class UserServiceImpl implements UserService {
//	static Logger log = LogManager.getLogger(UserServiceImpl.class);
//	
//    @Value("${encrypt_pass}")
//    private String encrypt_pass;
//    @Value("${user_23_encrypt_pass}")
//    private String user_23_encrypt_pass;
//    @Value("${default_icon}")
//    private String defaultIcon;
//    @Value("${bingdian_user_service_url}")
//    private String bingdian_user_service_url;
//    @Value("${qq_connect_appkey}")
//    private String qq_connect_appkey;
//    @Value("${qq_connect_secret}")
//    private String qq_connect_secret;
//    @Value("${mobile_bind_msg_kaqu}")
//    private String mobile_bind_msg_kaqu;
//    @Value("${image_show_url_pre}")
//    private String image_show_url_pre;
//    @Value("${temporary_image_directory}")
//    private String temporary_image_directory;
//    @Value("${server_image_directory}")
//    private String server_image_directory;
//    @Value("${server_image_address}")
//    private String server_image_address;
//
//
//	@Autowired
//	@Qualifier("jmsSender")
//	private TopicSender jmsSender;
//
//
//	@Override
//	public CS_Common authLogin(Map<String, Object> params, String project_type) throws FSException, IOException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common authBind(Map<String, Object> params) throws FSException, IOException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public void registerGetCode(String credential, String type) throws FSException, IOException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public CS_Common login(String username, String password, String type, String client_id, String ipAddr,
//			String version, String ky_app_id, String project_type) throws FSException, IOException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public void findPswGetCode(String credential, String type) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void findPsw(String credential, String type, String code, String password) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void findPswSetPassword(String credential, String type, String code, String password, String version,
//			String ky_app_id) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void updatePassword(String uid, String password) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void updateNickname(String uid, String display_name, String token) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void updateInfo(String uid, String display_name, String birthday, String gender, String email,
//			String address, String mobile, String code, String real_name, String token) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void addUserLoginRecord(int u_id, String client_id, String ip_address) {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public String decryptPassword(String content, String password) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public T_Wp_Users getUser(String username) throws FSException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public void generateAndSendCode(String credential, String type, String msg, String msgTitle) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void validCode(String credential, String type, String code) throws FSException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public void validCredentialGetCode(String credential, String type) throws FSException, IOException {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//	@Override
//	public CS_Common checkIn(int u_id) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common addBeansbyShare(int u_id, String platform, String type, String extra) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common updateUserLogo(int u_id, MultipartFile img) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common pushBindingUpload(int user_id, String clientId, String login_version) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common unbindweixin(String openid) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public CS_Common unbindUserToken(int userid, String source) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//	@Override
//	public String getOpenidByUserid(int userid) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
}
