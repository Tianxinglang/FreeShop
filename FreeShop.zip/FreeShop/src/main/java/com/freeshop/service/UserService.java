package com.freeshop.service;

public interface UserService {
//	/**
//	 * 授权登陆处理
//	 * @throws FSException
//	 * @throws IOException 
//	 * */
//	public CS_Common authLogin(Map<String,Object> params,String project_type) throws FSException, IOException;
//	
//	/**
//	 * 授权绑定处理
//	 * @return CS_Common
//	 * @throws FSException
//	 * @throws IOException 
//	 * */
//	public CS_Common authBind(Map<String,Object> params) throws FSException, IOException;
//	
//	/**
//	 * 注册 获取验证码
//	 * @throws FSException
//	 * @throws IOException 
//	 * */
//	public void registerGetCode(String credential,String type) throws FSException, IOException;
//	
//	/**
//	 * 注册 验证验证码并保存数据 并且设置密码
//	 * @param ip 
//	 * @return CS_User_Login
//	 * @throws FSException
//	 * */
////	public CS_User_Login registerSetPassword(F_Credential fc,String ip,String loginType,T_Usr_Tokens ut) throws FSException;
//
//	/**
//	 * 登录
//	 * @throws FSException
//	 * @throws IOException 
//	 * */
//	public CS_Common login(String username,String password,String type,String client_id, String ipAddr,String version,String ky_app_id,String project_type) throws FSException, IOException;
//	
//	/**
//	 * 找回  获取验证码
//	 * @throws FSException
//	 * */
//	public void findPswGetCode(String credential,String type) throws FSException;
//	
//	/**
//	 * 找回  验证验证码并保存数据
//	 * @return void
//	 * @throws FSException
//	 * */
//	public void findPsw(String credential,String type,String code,String password) throws FSException;
//	
//	/**
//	 * 找回  验证验证码并保存数据  并且设置密码
//	 * @throws FSException
//	 * */
//	public void findPswSetPassword(String credential, String type, String code,
//			String password,String version,String ky_app_id) throws FSException;
//	
//	/**
//	 * 修改密码
//	 * @throws FSException
//	 * */
//	public void updatePassword(String uid,String password) throws FSException;
//	
//	/**
//	 * 修改昵称
//	 * @throws FSException
//	 * */
//	public void updateNickname(String uid,String display_name,String token) throws FSException;
//
//	/**
//	 * 修改用户信息
//	 * @throws FSException
//	 * */
//	public void updateInfo(String uid, String display_name, String birthday,
//			String gender,String email,String address,String mobile,String code,String real_name,String token) throws FSException;
//	
//	 /**
//     * 增加登录记录
//     * */
//	public void addUserLoginRecord(int u_id, String client_id, String ip_address);
//	
//	 /**
//     * 解密
//     * */
//	public String decryptPassword(String content, String password);
//	
//	/**
//	 * 获取用户
//	 * @throws FSException
//	 * */
//	public T_Wp_Users getUser(String username) throws FSException;
//
//	/**
//	 * 生成发送验证码
//	 * */
//	public void generateAndSendCode(String credential, String type,String msg,String msgTitle)throws FSException;
//
//	/**
//	 * 验证验证码
//	 * */
//	public void validCode(String credential, String type, String code)
//			throws FSException;
//	
//	/** 注册 获取验证码
//	 * @throws FSException
//	 * @throws IOException 
//	 * */
//	public void validCredentialGetCode(String credential,String type) throws FSException, IOException;
//	
//	/**
//	 * 用户签到
//	 * @param u_id
//	 * @return
//	 * @throws Exception
//	 */
//	public CS_Common checkIn(int u_id) throws Exception;
//	/**
//	 * 分享资讯
//	 * @param u_id
//	 * @param points_opearte_code
//	 * @return
//	 * @throws Exception
//	 */
//	public CS_Common addBeansbyShare(int u_id,String platform,String type,String extra) throws Exception;
//	
//	/**
//	 * 修改用户头像
//	 * @param u_id
//	 * @param img
//	 * @return
//	 * @throws Exception
//	 */
//	public CS_Common updateUserLogo(int u_id,MultipartFile img) throws Exception;
//	/**
//	 * 上传绑定
//	 */
//	public CS_Common pushBindingUpload(int user_id,String clientId,String login_version);
//	/**
//	 * 微信解绑
//	 * @param openid
//	 * @return
//	 */
//	public CS_Common unbindweixin(String openid);
//	/**
//	 * 第三方解绑
//	 * @param openid
//	 * @return
//	 */
//	public CS_Common unbindUserToken(int userid,String source)throws Exception;
//	/**
//	 * 根据userid获取用户公众号的openid
//	 * @param userid
//	 * @return
//	 */
//	public String getOpenidByUserid(int userid);
//	/**
//     * php微信页面绑定手机号
//     * @return CS_User_Php_Weixin
//     */
////	public CS_Common weixinbindphp(String credential,String type,String code,T_Usr_Tokens ut) throws FSException;
//
}
