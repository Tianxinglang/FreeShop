package com.freeshop.controller;

import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import static com.freeshop.constant.LoggingCategory.User;
import com.freeshop.constant.Category;
import com.freeshop.controller.Base.BaseController;

@Controller
@RequestMapping(value = {"/admin" })
@Category(User)
public class UserVersionController extends BaseController {
	static Logger log = LogManager.getLogger(UserVersionController.class);

	/**
	 * 用户登录
	 */
	@RequestMapping(value = { "/login.html" })
	@ResponseBody
	public ModelAndView login(HttpServletRequest request) {
		return new ModelAndView("login");
	}

	/**
	 * 用户登录
	 */
	@RequestMapping(value = { "/index.html" })
	@ResponseBody
	public ModelAndView adminIndex(HttpServletRequest request) {
		return new ModelAndView("index");
	}
}
