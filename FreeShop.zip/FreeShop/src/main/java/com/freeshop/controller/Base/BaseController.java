package com.freeshop.controller.Base;

import org.apache.logging.log4j.ThreadContext;

import com.freeshop.constant.*;
import com.freeshop.domain.cs.CS_Common;
import com.freeshop.error.CommonError;

import javax.servlet.http.HttpServletRequest;

public class BaseController {
    protected void setLoggingEnvironment(Object u_id) {
        ThreadContext.put(LoggingKey.user_id.name(), (u_id!=null)?u_id.toString(): LoggingConstant.NOUSER);

        if ( BaseController.this.getClass().isAnnotationPresent(Category.class) ){
            Category c = BaseController.this.getClass().getAnnotation(Category.class);
            LoggingCategory lc = c.value();
            ThreadContext.put(LoggingKey.category.name(), lc.name());
        } else {
            ThreadContext.put(LoggingKey.category.name(), LoggingCategory.Default.name());
        }
    }

    protected Integer validateAndReturnUserID(HttpServletRequest request, CS_Common cs) {
        String token = request.getHeader("Authorization");
        // 验证数据的完整性
        if (token == null) {
            cs.setError(CommonError.InvalidToken);
            return -1;
        }
        Object u_id = request.getAttribute("u_id");

        if (u_id == null) {
            cs.setError(CommonError.InvalidToken);
            return -1;
        }
        setLoggingEnvironment(u_id);
        return Integer.parseInt(String.valueOf(u_id));
    }


}
