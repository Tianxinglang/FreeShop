package com.freeshop.constant;

public enum LoggingCategory {
    Card,
    Coupon,
    CustomService,
    Group,
    ThirdParty,
    Order,
    PointAct,
    Post,
    User,
    Prepay,
    Default,
    Tag,
    Message,
    Market,
    VipCard;

}
