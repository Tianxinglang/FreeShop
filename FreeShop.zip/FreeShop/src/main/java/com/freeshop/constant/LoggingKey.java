package com.freeshop.constant;

public enum LoggingKey {
    user_id,
    category

}
