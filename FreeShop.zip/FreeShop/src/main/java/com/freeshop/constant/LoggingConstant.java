package com.freeshop.constant;

public final class LoggingConstant {
    public static final String NOUSER = "0";
}
