package com.freeshop.constant;

/**
 * 公用常量
 * */
public class FreeShopConstant {

	
}
