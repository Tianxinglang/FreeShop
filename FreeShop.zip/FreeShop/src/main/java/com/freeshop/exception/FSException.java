package com.freeshop.exception;

import com.freeshop.error.IError;

/**
 * 定义异常类
 * */
public class FSException extends Exception {
	private final static long serialVersionUID = 6476473452739657628L;

	private IError error = null;

	public FSException(IError error) {
		this.error = error;
	}

	public int getCode() {
		return error.code();
	}

	@Override
	public String getMessage() {
		return error.message();
	}

	@Override
	public String getLocalizedMessage() {
		return getMessage();
	}

}
