package com.freeshop.error;

public enum CommonError implements IError{
    InvalidToken(-100, "无效令牌"),
    IncorrectSign(-101,"签名错误"),
    ParamMissing(-102, "缺少参数或参数为空"),
    IllegalParam(-103,"参数非法"),
    RequestNetFailed(-104,"网络异常"),
	UnknownError(-105, "其他错误"),
    TimeOutError(-106, "超时错误"),
    GroupViewerFailed(-107,"请求GroupViewer失败"),
	ThirdPartyFailed(-108,"请求ThirdParty失败"),
	BingDianUserFailed(-109,"请求BingDianUserService失败"),
    InvalidRegion(-110, "无效地区"),//无效地区
	SearchResultEmpty(-111,"空查询结果"),
	IllegalRequest(-112,"亲，有新系统更新，请更新后再试"),
	IllegalTimeError(-113,"亲，请校正系统时间后再操作"),
	NotAllowVersionLogin(-114,"-999"),
	WechatLoginFrequently(-115,"登录过于频繁，请于10分钟后再次登录");
	
    private int code;
    private String message;

    CommonError(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public int code() {
        return code;
    }

    @Override
    public String message() {
        return message;
    }
}
