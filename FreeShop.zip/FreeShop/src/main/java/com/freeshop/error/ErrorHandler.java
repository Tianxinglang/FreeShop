package com.freeshop.error;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.freeshop.domain.cs.CS_Common;
import com.freeshop.exception.FSException;

public class ErrorHandler {
	private static Logger log=LogManager.getLogger(ErrorHandler.class);
    // 用Exception中的信息填充CS_Common.
    public static void fillResultByException(CS_Common cs, Exception e) {
        if(e instanceof FSException){
            FSException b = (FSException)e;
            cs.setErr_code(b.getCode());
            cs.setErr_msg(e.getMessage());
        }else{
            cs.setErr_code(CommonError.UnknownError.code());
            cs.setErr_msg(CommonError.UnknownError.message());
            log.error(e.getMessage(),e);
        }
    }

}
