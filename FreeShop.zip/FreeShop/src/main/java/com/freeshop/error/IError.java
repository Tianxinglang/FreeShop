package com.freeshop.error;

public interface IError {
    int code();
    String message();
}
