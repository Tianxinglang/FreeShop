package com.freeshop.error;

public class CustomError implements IError {
	private int code;
	private String message;
	
	public CustomError(int code, String message) {
        this.code = code;
        this.message = message;
    }
	
    @Override
    public int code() {
        return code;
    }

    @Override
    public String message() {
        return message;
    }

}
