package com.freeshop.error;


public enum UserError implements IError {

	UserInfoGetedError(-200,"获取用户信息异常"), 
	OtherAccountBinded(-201,"已绑定其他账号"), 
	NotExistsUser(-202,"用户不存在"), 
	DeviceHasRegistered(-203,"该设备已注册"), 
	WrongEncryption(-204,"用户密钥有误，请退出重新登录"), 
	EmailNotBinded(-205,"未绑定邮箱"), 
	IllegalEmail(-206,"非法邮箱"),
	AlsoBinded(-207,"该微信号已绑定过"),
	MobileCannotUnbind(-208,"手机号不能解绑"),
	EmptyParam(-209,"参数为空"),
	NoMobileCannotUnbind(-210,"未绑定手机号,不能解绑"),
	VuserCannot(-211,"游客无法使用社交功能");
	
    private int code;
    private String message;

    UserError(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public int code() {
        return code;
    }

    @Override
    public String message() {
        return message;
    }
}
