package com.freeshop.error;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

@Service
public class ListenerErrorHandler implements ErrorHandler{

	private  static Logger log=Logger.getLogger(ListenerErrorHandler.class);
	
    @Override
    public void handleError(Throwable t) {
        log.error("Error in listener", t);
    }

}
