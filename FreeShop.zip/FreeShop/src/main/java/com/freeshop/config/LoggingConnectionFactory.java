package com.freeshop.config;

import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;

import com.freeshop.utils.PropertiesUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;


public class LoggingConnectionFactory {
    private static interface Singleton {
        final LoggingConnectionFactory INSTANCE = new LoggingConnectionFactory();
    }

    private static final String db = PropertiesUtil.readStringValue("loggingdb.url");
    private static final String username = PropertiesUtil.readStringValue("loggingdb.username");
    private static final String password = PropertiesUtil.readStringValue("loggingdb.password");
    private final DataSource dataSource;

    private LoggingConnectionFactory() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.exit(0);
        }
        Properties properties = new Properties();
        properties.setProperty("user", username);
        properties.setProperty("password", password);
        GenericObjectPool pool = new GenericObjectPool();
        DriverManagerConnectionFactory connectionFactory = new DriverManagerConnectionFactory(db,properties);

        new PoolableConnectionFactory(connectionFactory, pool, null, "SELECT 1",3,false,false, Connection.TRANSACTION_REPEATABLE_READ);
        this.dataSource = new PoolingDataSource(pool);

    }

    public static Connection getDatabaseConnection() throws SQLException {
        return Singleton.INSTANCE.dataSource.getConnection();
    }
}
