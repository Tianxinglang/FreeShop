package com.freeshop.job;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.freeshop.mq.sender.TopicSender;

@Component
public class PoinActOverdueMessageNotifyJob {
	private static Logger log=LogManager.getLogger(PoinActOverdueMessageNotifyJob.class);
	@Autowired
	@Qualifier("jmsSender")
	private TopicSender jmsSender;
	
	  @Scheduled(cron = "0 0 0 * * ?")  
	  public void poinActOverdueMessageNotify(){
		  log.info("开始执行定时器,进行集点过期消息提醒");
		  //发送消息
		  jmsSender.sendPointActNotifyMessage(2,0); 
	  }
}
