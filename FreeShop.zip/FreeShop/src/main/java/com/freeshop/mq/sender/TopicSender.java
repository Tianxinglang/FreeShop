
package com.freeshop.mq.sender;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.freeshop.utils.DateUtil;

import net.sf.json.JSONObject;

/**
 * 发送消息实体类
 *
 */
@Component("jmsSender")
public class TopicSender {
	private static Logger log=LogManager.getLogger(TopicSender.class);
	@Autowired
	@Qualifier("topicJmsTemplate")
	private JmsTemplate jmsTemplate;
	
	private final String destinationName="cardqu.topic";
	
	/**
	 * 发送集点卡相关信息
	 * @param u_id
	 * @param map
	 * @param type(1:集点卡信息提醒  2集点卡过期信息提醒(uid==0))
	 */
	public void sendPointActNotifyMessage(int type,int uid)
	{
		final JSONObject message=new JSONObject();
	  	if(type==1){
			message.accumulate("type", "messageNotify");
	 		message.accumulate("uid", uid);
	  	}else{
			message.accumulate("type", "messageNotify_overdue");
	  	}
		 log.info("集点卡过期触发:"+message.toString());
		try {
			jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送<集点卡提醒>消息");
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}

	/**
	 * 增加积分操作信息
	 * @param u_id
	 * @param pointType
	 * @param map
	 */
	public void sendAddPointsMessages(int u_id,int pointType,Map<String,Object> map) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "pointOperate");
		  message.accumulate("uid", u_id);
		  message.accumulate("pointType", pointType);
		  if(map!=null && !map.isEmpty())
		  {
			  message.accumulate("params", JSONObject.fromObject(map));
		  }
		  log.info("积分增加触发:"+message.toString());
		try {
			jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
	/**
	 * 发送 绑定会员卡,绑定其他卡,添加集点卡,完成集点信息
	 * @param u_id
	 * @param operateType
	 * @param cardnumber
	 */
	public void sendKindsOfMessages(int u_id,int operateType,String cardnumber,String groupId) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "kindsOperate");
		  message.accumulate("uid", u_id);
		  message.accumulate("operateType", operateType);
		  message.accumulate("cardnumber", cardnumber);
		  message.accumulate("groupId", groupId);
		  log.info("绑卡触发:"+message.toString());
		try {
			 jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
	
	/**
	 * 常客卡退款更新，发票申请状态变更，核销点数后请求评价，转赠后添加消息
	 * @param u_id
	 * @param operateType
	 * @param operateInfo
	 * @param context
	 */
	public void sendPrepayMessages(int u_id,int operateType,String operateInfo,String context) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "prepayOperate");
		  message.accumulate("uid", u_id);
		  message.accumulate("operateType", operateType);
		  message.accumulate("operateInfo", operateInfo);
		  message.accumulate("context", context);
		  log.info("常客卡触发:"+message.toString());
		try {
			 jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
	
	/**
	 * 常客卡消费时添加集点卡并且集点
	 * @param u_id
	 * @param operateInfo
	 * @param context
	 */
	public void sendPrepayTradeMessages(int u_id,Map<String,Object> map) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "prepayTrade");
		  message.accumulate("uid", u_id);
		  if(map!=null && !map.isEmpty())
		  {
			 Set<Map.Entry<String,Object>> set= map.entrySet();
			 Iterator<Map.Entry<String,Object>> it=set.iterator();
			  while(it.hasNext()){
				  Map.Entry<String,Object> entry= it.next();
				  message.accumulate(entry.getKey(), entry.getValue());	  
			  }
		  }
		  log.info("常客卡消费:"+message.toString());
		try {
			 jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
	/**
	 * 趣豆等级提升消息
	 * @param u_id
	 * @param map
	 */
	public void sendPointsLevelMessages(int u_id) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "pointslevel_promote");
		  message.accumulate("uid", u_id);
		  log.info("趣豆等级:"+message.toString());
		try {
			 jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
	/**
	 * 推荐有礼代金券发放
	 * @param u_id
	 * @param pointType
	 * @param map
	 */
	public void sendIssueCouponsToRecommendersMessages(int u_id,Map<String,Object> map,int from_uid) {
		  final JSONObject message=new JSONObject();
		  message.accumulate("type", "recommendCoupons");
		  message.accumulate("uid", u_id);
		  message.accumulate("from_uid", from_uid);
		  if(map!=null && !map.isEmpty())
		  {
			  message.accumulate("params", JSONObject.fromObject(map));
		  }
		  log.info("推荐有礼代金券发放触发:"+message.toString());
		try {
			jmsTemplate.send(destinationName,new MessageCreator() {
				
				@Override
				public Message createMessage(Session session) throws JMSException {
					log.info("Sender 于"+DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")+"发送了一条消息，消息为"+message.toString());
					return session.createObjectMessage(message);
				}
				
			});
		} catch (JmsException e) {
			log.error("发送消息失败，失败原因:"+e.getMessage());
		}
	}
	
}
