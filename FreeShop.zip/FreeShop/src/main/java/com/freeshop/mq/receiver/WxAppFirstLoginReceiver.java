package com.freeshop.mq.receiver;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.freeshop.error.CommonError;
import com.freeshop.exception.FSException;
import com.freeshop.utils.StringUtils;

@Component("wxAppFirstLoginReceiver")
public class WxAppFirstLoginReceiver implements MessageListener{
	private static Logger log=LogManager.getLogger(WxAppFirstLoginReceiver.class);

	
	@Override
	public void onMessage(Message message) {
		ObjectMessage obj=(ObjectMessage)message;
		JSONObject jsonObj;
		try {
			jsonObj = (JSONObject)obj.getObject();
			if(jsonObj==null ||  jsonObj.isEmpty() || !jsonObj.containsKey("type") 
					|| !"wxapp_first_login".equals(jsonObj.getString("type")))
			{
				return ;
			}
			
			log.info("微信版app第一次登录发卡--美式一杯");
			
			String u_id=jsonObj.getString("uid");
			String prepay_id=jsonObj.getString("prepay_id");
			if(StringUtils.isEmpty(u_id)||StringUtils.isEmpty(prepay_id))
			{
				throw new FSException(CommonError.ParamMissing);
			}
//			prepayService.distributeSinglePrepayToUser(Integer.valueOf(u_id), Integer.valueOf(prepay_id));
			
		} catch (JMSException e) {
			log.error("Jms消息接收处理失败，失败原因:"+e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("发卡失败，失败原因:"+e.getMessage());
		}
	}
	
}
