package com.freeshop.repository;


import java.util.List;

import com.freeshop.domain.table.T_Usr_Tokens;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;



/**
 * Created by zhawei on 14-3-18.
 * 权限验证
 * updated by zhagnhuyi on 14-3-28
 */
public interface UsrTokenRepository extends JpaRepository<T_Usr_Tokens,Integer>{
	
    @Query(value = "select ut from T_Usr_Tokens ut where ut.token=?1")
    public T_Usr_Tokens validByToken(String token);

    @Query(value = "select ut from T_Usr_Tokens ut where ut.token=:token")
    public T_Usr_Tokens getByToken(@Param("token") String token);
    
    @Query(value = "select ut from T_Usr_Tokens ut where ut.identity_no=:identity_no and ut.source=:source order by ut.create_time desc")
    public List<T_Usr_Tokens> listByIdentitynoSource(@Param("identity_no") String identity_no, @Param("source") String source);
    
    @Query(value = "select ut from T_Usr_Tokens ut where ut.u_id=:u_id and ut.source=:source order by ut.create_time desc")
    public List<T_Usr_Tokens> listByUidSource(@Param("u_id") int u_id, @Param("source") String source);

    @Query(value = "select ut from T_Usr_Tokens ut where ut.u_id=:u_id and ut.source !=:source")
    public List<T_Usr_Tokens> listByUidExceptSource(@Param("u_id") int u_id, @Param("source") String source);
   
    @Query(value = "select ut from T_Usr_Tokens ut where ut.u_id=:u_id")
    public List<T_Usr_Tokens> listByUid(@Param("u_id") int u_id);
    
    @Query(value = "select ut from T_Usr_Tokens ut where ut.u_id=:u_id and ut.source=:source")
    public List<T_Usr_Tokens> listByUidAndSource(@Param("u_id") int u_id, @Param("source") String source);
    
    @Query(value = "select ut from T_Usr_Tokens ut where ut.secret=:unionid and ut.source=:source")
    public T_Usr_Tokens getByUnionidSource(@Param("unionid") String unionid, @Param("source") String source);
}
