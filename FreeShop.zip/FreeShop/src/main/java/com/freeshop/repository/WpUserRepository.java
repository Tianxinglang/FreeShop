package com.freeshop.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.freeshop.domain.table.T_Wp_Users;

public interface WpUserRepository extends JpaRepository<T_Wp_Users,Integer>{
    
	@Query(value = "select t.user_login from T_Wp_Users t where t.user_login like ?1")
    public List<String> listByUserlogin(String user_login);
	
	@Query(value = "select t from T_Wp_Users t where t.user_login=:user_login")
	public T_Wp_Users getByUserlogin(@Param("user_login")String user_login);
	
	@Query(value = "select t from T_Wp_Users t where t.email_login=:email_login")
	public T_Wp_Users getByEmaillogin(@Param("email_login")String email_login);
	
	@Query(value = "select t from T_Wp_Users t where t.mobile_login=:mobile_login")
	public T_Wp_Users getByMobilelogin(@Param("mobile_login")String mobile_login);

	@Query(value = "select t.user_nicename from T_Wp_Users t where t.user_nicename like ?1")
    public List<String> listByNickname(String user_nicename);
	
	@Query(value = "select count(t.id) from T_Wp_Users t where t.user_nicename =:user_nicename and t.id!=:id")
	public int getCountByNicknameExcepUid(@Param("user_nicename")String user_nicename,@Param("id")int id);
	
	@Query(value = "select user_status from T_Wp_Users where id=:id")
	public Integer getStatusById(@Param("id")int id);
	
	@Query(value = "select t from T_Wp_Users t where t.user_status='0'")
    public List<T_Wp_Users> listByStatus();
    
	@Query(value = "select user_registered from T_Wp_Users where id=:id")
	public Date getRegisteredById(@Param("id")int id);
	
	@Query(value = "select a from T_Wp_Users a where a.id=:id")
	public T_Wp_Users getWpUserById(@Param("id")int id);
	
	@Transactional
	@Modifying
	@Query(value = "update T_Wp_Users set user_url=:user_url where id=:uid")
	public void updateUserUrl(@Param("user_url")String user_url,@Param("uid")int uid);

}
