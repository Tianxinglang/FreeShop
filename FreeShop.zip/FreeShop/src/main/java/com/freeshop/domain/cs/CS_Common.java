package com.freeshop.domain.cs;

import java.lang.reflect.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.freeshop.error.IError;

/**
 * 响应客户端公用类
 * */
public class CS_Common {
	private static final String CS_PACKAGE = "com.freeshop.domain.cs";
	private int err_code=0;// 错误码    0：成功，小于0：失败，大于0：表示正确返回，但有特殊提示
	private String err_msg="成功";// 出错提示信息 默认成功
	private long ts;// 服务器处理请求开始时间戳，用于客户端与服务器对时或者评估延迟
    private String message_show= "";//默认返回空值
	public int getErr_code() {
		checkStringNull(this);
		return err_code;
	}

	public void setError(IError error) {
		setErr_code(error.code());
		setErr_msg(error.message());
	}
	
	@JsonIgnore
	public boolean isSucc() {
		return getErr_code()==0;
	}

	public void setErr_code(int err_code) {
		this.err_code = err_code;
	}

	public String getErr_msg() {
		return err_msg;
	}

	public void setErr_msg(String err_msg) {
		this.err_msg = err_msg;
	}

	public long getTs() {
		return ts;
	}

	public void setTs(long ts) {
		this.ts = ts;
	}

	public String getMessage_show() {
		return message_show;
	}

	public void setMessage_show(String message_show) {
		this.message_show = message_show;
	}
	
	/**
	 * 检查返回的字符串为空的情况，并设置为空字符串
	 * */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private <T> void checkStringNull(Object obj){
		try {
			Class<? extends T> c =(Class<? extends T>) obj.getClass();
			Field[] fs = c.getDeclaredFields();
			for(Field f:fs){
				if(f.getType().getName().equals("java.lang.String")){
					f.setAccessible(true);
					if(f.get(obj)==null){
						f.set(obj,"");
					}
				}else if (f.getType().getName().equals("java.util.List")){
					f.setAccessible(true);
					if(f.get(obj)==null){
						f.set(obj,new java.util.ArrayList());
					}else{
						for(int i=0;i<((java.util.List)f.get(obj)).size();i++){
							if(((java.util.List)f.get(obj)).get(i).getClass().getName().contains(CS_PACKAGE)){
								checkStringNull(((java.util.List)f.get(obj)).get(i));
							}
						}
					}
				}else if (f.getType().getName().contains(CS_PACKAGE)){
					f.setAccessible(true);
					if(f.get(obj)==null){
						f.set(obj,f.getType().newInstance());
					}else{
						checkStringNull(f.get(obj));
					}
				}
			}
		} catch (Exception e) {
			
		}
	}
}
