package com.freeshop.utils;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;

public class StringUtils extends org.apache.commons.lang.StringUtils {
	
	public static final String CANCEL_DOUBLE_FORMAT="###";
	public static final String STRING_NUMBER="0123456789";
	public static final String STRING_NUMBER_LOWERCASE="0123456789abcdefghijklmnopqrstuvwxyz";
	public static final String STRING_NUMBER_UPPERCASE="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final String REGEX_EMAIL = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
	public static final String REGEX_MOBILE = "^\\d{11}$";//验证是11位的手机号码
	public static final String REGEX_MOBILE_EXACT = "^1[3|4|5|7|8][0-9]{9}$";//验证是具体的11位的手机号码
	public static final String REGEX_HOME_TEL="^\\d{3}-\\d{8}|\\d{4}-\\d{8}$";//验证是021-或0512-等固定电话
	public static final String REGEX_HOME_EXACT="^\\d{3}-\\d{3}-\\d{4}$";//验证是400-717-1717一类电话
	
	
	public static String getMidStr(String str, String startStr, String endStr) {
		if (str == null) {
			return null;
		}
		int a = str.indexOf(startStr);

		if (a != -1) {
			str = str.substring(a + startStr.length());
			int b = str.indexOf(endStr);
			if (b != -1) {
				str = str.substring(0, b);
				return str;
			}
		}
		return null;
	}

	/**
	 * 在数字前面添0，满足bits位数
	 * 
	 * @param num
	 * @param bits
	 * @return
	 */
	public static String numAddZeroBeforeString(Integer num, int bits) {
		if (num != null) {
			String numString = num.toString();
			int len = numString.length();
			if (len >= bits) {
				return num.toString();
			} else {
				int margin = bits - len;
				while (margin > 0) {
					numString = "0" + numString;
					margin--;
				}
			}
			return numString;
		}
		return null;
	}
	
	/**
	 * 按字节长度截取字符串，可以是中英文混排
	 * @param s 要截取的目标字符串
	 * @param length 截取长度
	 * @return
	 */
	public static String multiSubStr(String s, int len) {
		if (s == null) {
			return "";
		}
		try {
			if (s.getBytes("Unicode").length <= len) {
				return s;
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return multiSubstring2(s, len) + "...";
	}
	
	/**
	 * 按字节长度截取字符串
	 * @param s 要截取的目标字符串
	 * @param length 截取长度
	 * @return
	 */
	public static String multiSubstring2(String s, int length) {
		String s1 = s;
		try{
		byte[] bytes = s.getBytes("Unicode");
		int n = 0; // 表示当前的字节数
		int i = 2; // 要截取的字节数，从第3个字节开始

		for (; i < bytes.length && n < length; i++) {
			// 奇数位置，如3、5、7等，为UCS2编码中两个字节的第二个字节
			if (i % 2 == 1) {
				n++; // 在UCS2第二个字节时n加1
			} else {
				// 当UCS2编码的第一个字节不等于0时，该UCS2字符为汉字，一个汉字算两个字节
				if (bytes[i] != 0) {
					n++;
				}
			}
		}

		// 如果i为奇数时，处理成偶数
		if (i % 2 == 1) {
			// 该UCS2字符是汉字时，去掉这个截一半的汉字
			if (bytes[i - 1] != 0) {
				i = i - 1;
			}
			// 该UCS2字符是字母或数字，则保留该字符
			else {
				i = i + 1;
			}
		}
		
		s1 =  new String(bytes, 0, i, "Unicode");
		}catch(UnsupportedEncodingException u){
			u.printStackTrace();
		}
		return s1;
	}
	
	
	
	/**
	 * 字符串是否在字符串数组中 忽略大小写
	 * 
	 * @param url
	 *            字符串
	 * @param allUrl
	 *            字符串数组
	 * @return
	 */
	public static boolean in(String url, String[] allUrl) {
	    if (StringUtils.isEmpty(url)) {
	        return false;
        }
	    if (allUrl==null||allUrl.length==0) {
	        return false;
        }
		for (int i = 0; i < allUrl.length; i++) {
			if (allUrl[i].equalsIgnoreCase(url)) {
				return true;
			}
		}
		return false;
	}
	/**
	 * 检查指定的字符串是否为空。
	 * <ul>
	 * <li>SysUtils.isEmpty(null) = true</li>
	 * <li>SysUtils.isEmpty("") = true</li>
	 * <li>SysUtils.isEmpty("   ") = true</li>
	 * <li>SysUtils.isEmpty("abc") = false</li>
	 * </ul>
	 * 
	 * @param value 待检查的字符串
	 * @return true/false
	 */
	public static boolean isEmpty(String value) {
		int strLen;
		if (value == null || (strLen = value.length()) == 0) {
			return true;
		}
		for (int i = 0; i < strLen; i++) {
			if ((Character.isWhitespace(value.charAt(i)) == false)) {
				return false;
			}
		}
		return true;
	}


	/**
	 * 检查指定的字符串列表是否不为空。
	 */
	public static boolean areNotEmpty(String... values) {
		boolean result = true;
		if (values == null || values.length == 0) {
			result = false;
		} else {
			for (String value : values) {
				result &= !isEmpty(value);
			}
		}
		return result;
	}

	/**
	 * 把通用字符编码的字符串转化为汉字编码。
	 */
	public static String unicodeToChinese(String unicode) {
		StringBuilder out = new StringBuilder();
		if (!isEmpty(unicode)) {
			for (int i = 0; i < unicode.length(); i++) {
				out.append(unicode.charAt(i));
			}
		}
		return out.toString();
	}
	
    /**
     * <p>Checks if a String is not empty ("") and not null.</p>
     *
     * <pre>
     * StringUtils.isNotEmpty(null)      = false
     * StringUtils.isNotEmpty("")        = false
     * StringUtils.isNotEmpty(" ")       = false
     * StringUtils.isNotEmpty("bob")     = true
     * StringUtils.isNotEmpty("  bob  ") = true
     * </pre>
     *
     * @param str  the String to check, may be null
     * @return <code>true</code> if the String is not empty and not null
     */
    public static boolean isNotEmptyTrim(String str) {
         if(!StringUtils.isEmpty(str)){
        	 if(!str.trim().equals("")){
        		 return true;
        	 }
         }
         return false;
    }
    
    
    /**
	 * 在数字前面添0，满足bits位数
	 * @param str
	 * @param n
	 * @return
	 */
	public static String addZero(String str, int n) {
		int len = str.length();
		if(len >= n) {
			return str;
		} 
		int margin = n - len;
		while(margin > 0) {
			str = "0" + str;
			margin--;
		}
		return str;
	}
	
	/**
	 * 科学计数法转换成普通计数 小数位将清空
	 * @param String str
	 * @return String
	 * */
	public static String cancelScience(String str) {
		Double d = Double.valueOf(str);
		return cancelScience(d);
	}
	
	/**
	 * 科学计数法转换成普通计数 小数位将清空
	 * @param Double d
	 * @return String
	 * */
	public static String cancelScience(Double d) {
		DecimalFormat df = new DecimalFormat(CANCEL_DOUBLE_FORMAT);
		return df.format(d);
	}

	/**
	 * 科学计数法转换成普通计数  指定格式 
	 * @param String str
	 * @return String
	 * */
	public static String cancelScience(String str ,String format) {
		Double d = Double.valueOf(str);
		return cancelScience(d,format);
	}
	
	/**
	 * 科学计数法转换成普通计数  指定格式
	 * @param Double d
	 * @return String
	 * */
	public static String cancelScience(Double d,String format) {
		DecimalFormat df = new DecimalFormat(format);
		return df.format(d);
	}
	
	/**
	 * 返回目标字符串的字节长度
	 * @param str
	 * @return
	 */
	public static int getLength(String str){
		try {
			return str.getBytes("Unicode").length;
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * 以字节截取中英文     
	 * @param s String字符串
	 * @param length  需要的长度
	 * @param appendStr 超过长度 补充字符串 如“...”
	 * */
    public static String byteSubString(String s, int length,String appendStr){
    	if(s==null || s.equals("")){
    		return "";
    	}
		String str = s.substring(0, s.length()>length?length:s.length());
		StringBuffer sb = new StringBuffer("");
		char[] cs = str.toCharArray();
		int count = 0;
		for(char c : cs){
			if(count>length){
				break;
			}
			if(c >= 0x0391 && c <= 0xFFE5){  //中文字符
					// || (c>=0x0000 && c<=0x00FF))   //英文字符
				count = count+2;
				if(count>length){
					break;
				}
				sb.append(c);
			}else{
				sb.append(c);
				count = count+1;
			}
		}
		if(count>=length){
			if(!sb.toString().equals(s)){
				sb.append(appendStr);
			}
		}
		return sb.toString();
	} 
	
    /**
     * 随机获取含数字和小写字母的字符串
     * */
    public static String randStringUpper(int n){
    	StringBuffer sb = new StringBuffer("");
    	for(int i=0;i<n;i++){
    		int k = new Random().nextInt(STRING_NUMBER_UPPERCASE.length());
    		sb.append(STRING_NUMBER_UPPERCASE.charAt(k));
    	}
    	return sb.toString();
    }
    
	/**
     * 随机获取含数字和小写字母的字符串
     * */
    public static String randString(int n){
    	StringBuffer sb = new StringBuffer("");
    	for(int i=0;i<n;i++){
    		int k = new Random().nextInt(STRING_NUMBER_LOWERCASE.length());
    		sb.append(STRING_NUMBER_LOWERCASE.charAt(k));
    	}
    	return sb.toString();
    }
    
	/**
     * 随机获取含数字
     * */
    public static String randStringNum(int n){
    	StringBuffer sb = new StringBuffer("");
    	for(int i=0;i<n;i++){
    		int k = new Random().nextInt(STRING_NUMBER.length());
    		sb.append(STRING_NUMBER.charAt(k));
    	}
    	return sb.toString();
    }
    
	 /**
     * 根据给定的数组，得到最大的最后位数值+1 的 字符串
     * */
    public static String maxStringNo(List<String> list,String str){
    	if(list==null||list.isEmpty()){
    		return str;
    	}
    	int k = 0;
    	for(String s : list){
    		String[] arr = s.substring(str.length()-1).split("_");
    		if(arr.length>1){
    			String a = arr[arr.length-1];
				try {
					int b = Integer.parseInt(a);
					if(b>k){
    					k=b;
    				}
				} catch (NumberFormatException e) {
				}
    		}
    	}
    	return str+"_"+(k+1);
    }
    
    public static String indexToUpcase(String s){
    	if(!isNotEmptyTrim(s)){
    		return "";
    	}
    	if(s.length()==1){
    		return String.valueOf(s.charAt(0)).toUpperCase();
    	}
    	return String.valueOf(s.charAt(0)).toUpperCase()+s.substring(1);
    }
    
    public static String removeCommnBlankDecimalpoint(String s){
		if(StringUtils.isNotEmptyTrim(s)){
			s = s.trim().replaceAll(" ", "").replaceAll(",", "").replaceAll("，", "");
			if(NumberUtils.isNumeric(s)){
				double p = Double.parseDouble(s);
				return ((int)Math.floor(p))+"";
			}
			return s;
		}
		return "";
	}
    /**
     * 随机获取指定长度的数字或者字母组合
     * @param length
     * @return
     */
	public static String randomPromotion(int length) {
		String val = "";
		Random random = new Random();

		// 参数length，表示生成几位随机数
		for (int i = 0; i < length; i++) {

			String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
			// 输出字母还是数字
			if ("char".equalsIgnoreCase(charOrNum)) {
				// 输出是大写字母还是小写字母
				int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
				val += (char) (random.nextInt(26) + temp);
			} else if ("num".equalsIgnoreCase(charOrNum)) {
				val += String.valueOf(random.nextInt(10));
			}
		}
		return val;
	}
	
	public static void main(String[] args) {
		System.out.println(StringUtils.randomPromotion(15));
	}
}
