package com.freeshop.utils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;


public class Excel {
	
	/**
	 * 生成报表excel
	 * 
	 * @param sheetName Sheet1名称
	 * @param name 报表名称
	 * @param reports 报表明细数据 格式 二维数组(List 存放一个Object[]数组)
	 * @param detailTitle 明细头(标题)
	 * @return
	 * */
	public static HSSFWorkbook makeExcel(String sheetName,String name ,List<Object[]> reports,List<String> detailTitle) {
		
	    	HSSFSheet sheet = null;
	        HSSFWorkbook workbook = new HSSFWorkbook();
            
	        //得到所有格式 Map
	        Map<String,CellStyle> styles = getCellStyle(workbook);
	        sheet = workbook.createSheet(sheetName==null||sheetName.equals("")?"Sheet1":sheetName);
	        //设定所有明细宽度
	        
	        //Object[] tempObjectArr = (Object[])reports.get(0);
	        int widthLong = detailTitle.size();
	        for(int i=0;i<widthLong;i++){
	            sheet.setColumnWidth(i, 22*256);
	          //  sheet.autoSizeColumn(i, true);
	        }
	        
	        int count =0;//记录行
	        if(name!=null&&!name.equals("")){
		        HSSFRow row0 = sheet.createRow(count++);
		        HSSFCell cell = row0.createCell(0);
		        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(name);
		        cell.setCellStyle((CellStyle)styles.get("firstline"));
		        
		        sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, widthLong-1));
		        count++;
	        }
	        /*//当条件为单数时，增加，以使格式一致
            if(keyTitle.size()%2!=0){
            	keyTitle.add("");
            	valTitle.add("");
            }
	        for(int i=0;i<keyTitle.size()-1;i++){
		        HSSFRow rowtitel1 = sheet.createRow(count++);
		        HSSFCell celltitel1 = rowtitel1.createCell(0);
		        celltitel1.setCellType(HSSFCell.CELL_TYPE_STRING);
		        celltitel1.setCellValue((String)keyTitle.get(i));
		        celltitel1.setCellStyle((CellStyle)styles.get("condition"));
		        
		        HSSFCell celltitel2 = rowtitel1.createCell(1);
		        celltitel2.setCellType(HSSFCell.CELL_TYPE_STRING);
		        celltitel2.setCellValue((String)valTitle.get(i));
		        celltitel2.setCellStyle((CellStyle)styles.get("condition"));
		        sheet.addMergedRegion(new CellRangeAddress(count-1, count-1, 1, 2));
		        
		        HSSFCell celltitel5 = rowtitel1.createCell(5);
		        celltitel5.setCellType(HSSFCell.CELL_TYPE_STRING);
		        celltitel5.setCellValue((String)keyTitle.get(++i));
		        celltitel5.setCellStyle((CellStyle)styles.get("condition"));
		        
		        HSSFCell celltitel6 = rowtitel1.createCell(6);
		        celltitel6.setCellType(HSSFCell.CELL_TYPE_STRING);
		        celltitel6.setCellValue((String)valTitle.get(i));
		        celltitel6.setCellStyle((CellStyle)styles.get("condition"));
		        sheet.addMergedRegion(new CellRangeAddress(count-1, count-1, 6, 7));
	        }*/
        	if(detailTitle instanceof List){
                HSSFRow row1 = sheet.createRow((count++));
                List<String> detailTitleList = (List<String>)detailTitle;
                for(int j=0;j<detailTitleList.size();j++){
                	 HSSFCell cell10 = row1.createCell(j);
                	 cell10.setCellType(HSSFCell.CELL_TYPE_STRING);
                	 cell10.setCellValue((String)detailTitleList.get(j));
                	 cell10.setCellStyle((CellStyle)styles.get("detailTitle"));
                }
        	}
        	
	        for (int i = 0; i < reports.size(); i++) {
	                
	        	    Object[] report = (Object[])reports.get(i);
	               
	                HSSFRow rowX = sheet.createRow((count++));
	                //第一列为序号列
	                //HSSFCell cellY1 = rowX.createCell(0);
	                //cellY1.setCellType(HSSFCell.CELL_TYPE_STRING);
	                //cellY1.setCellStyle((CellStyle)styles.get("string"));
	                //cellY1.setCellValue(i+1);
	                for (int y = 0; y < report.length; y++) {
	                    HSSFCell cellY = rowX.createCell(y);
	                    if(report[y] instanceof BigDecimal ){//判断是否是BigDecimal列
	                    	cellY.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	                    	boolean amount = false; //是否是金额列
	                    	if(amount){
	                    		Object object = null;
		                    	if(report[y]==null||report[y].equals("")){
		                    		object = 0;
		                    	}else{
		                    		object = report[y];
		                    	}
			                    BigDecimal bdi = new BigDecimal(String.valueOf(object));
			                    cellY.setCellValue(bdi.doubleValue());
			                    cellY.setCellStyle((CellStyle)styles.get("amount"));
	                    	}else{
		                    	cellY.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		                    	if(report[y]!=null&&!report[y].equals("")){
		                    	     BigDecimal bdi = new BigDecimal(String.valueOf(report[y]));
			                         cellY.setCellValue(bdi.doubleValue());
		                    	}
			                    cellY.setCellStyle((CellStyle)styles.get("number"));
	                    	}
	                    	
	                    } else if(report[y] instanceof Integer ){
	                    	cellY.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		                    cellY.setCellValue(Integer.parseInt(String.valueOf(report[y])));
		                    cellY.setCellStyle((CellStyle)styles.get("number"));
	                    	
	                    } else if(report[y] instanceof Double ){
	                    	cellY.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		                    cellY.setCellValue(Double.parseDouble((String)report[y]));
		                    cellY.setCellStyle((CellStyle)styles.get("number"));
	                    } else {
		                    cellY.setCellType(HSSFCell.CELL_TYPE_STRING);
		                    cellY.setCellStyle((CellStyle)styles.get("string"));
		                    Object object = null;
	                    	if(report[y]==null||report[y].equals("")){
	                    		object = "";
	                    	}else{
	                    		object = report[y];
	                    	}
		                    cellY.setCellValue(String.valueOf(object));
	                    }
	                }
	            
	        }
	        return workbook;

	 }
	/**
	 *根据给定的数字得到对应的字母
	 * *//*
	 private static String getStringABC(int i){
		 String[] s = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
		 return s[i];
	 }*/
	 
	 /**
	  *设置所有需要的格式
	  *
	  *@param workbook
	  *@return map  包含所有需要的格式
	  * */
	 private  static Map<String,CellStyle> getCellStyle(HSSFWorkbook workbook){
		 
		  Map<String,CellStyle> styles = new HashMap<String,CellStyle>();
		  
		  CellStyle styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_RIGHT);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          Font fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 12);
          fontContent.setFontName("宋体");
          styleTmep.setFont(fontContent);
          styleTmep.setDataFormat(workbook.createDataFormat().getFormat("￥0.00"));
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("amount", styleTmep);//金额格式
          
		  styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_RIGHT);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 12);
          fontContent.setFontName("宋体");
          fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
          styleTmep.setFont(fontContent);
          styleTmep.setDataFormat(workbook.createDataFormat().getFormat("￥0.00"));
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("lastAmount", styleTmep);//最后一行金额格式
          
          styleTmep = workbook.createCellStyle();
          fontContent = workbook.createFont();
          fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
          fontContent.setFontName("宋体");
          fontContent.setFontHeightInPoints((short) 12);
          styleTmep.setFont(fontContent);
	      styles.put("condition", styleTmep);//  条件格式
	      
	      styleTmep = workbook.createCellStyle();
	      fontContent = workbook.createFont();
	      fontContent.setFontHeightInPoints((short) 12);
	      fontContent.setFontName("宋体");
	      styleTmep.setFont(fontContent);
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("string", styleTmep);//  明细字符串统一格式 
          
          styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 12);
          fontContent.setFontName("宋体");
          styleTmep.setFont(fontContent);
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("number", styleTmep);//数字格式
          
          styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 12);
          fontContent.setFontName("宋体");
          fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
          styleTmep.setFont(fontContent);
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("lastNumber", styleTmep);//最后一行数字格式
          
          styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 12);
          fontContent.setFontName("宋体");
          fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
          styleTmep.setFont(fontContent);
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styles.put("lastline", styleTmep);//最后一行格式
          
          styleTmep = workbook.createCellStyle();
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          
          fontContent = workbook.createFont();
          fontContent.setFontHeightInPoints((short) 18);
          fontContent.setFontName("宋体");
          fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
          styleTmep.setFont(fontContent);
          styles.put("firstline", styleTmep);//第一行格式
          
	      styleTmep = workbook.createCellStyle();
	      fontContent = workbook.createFont();
	      fontContent.setFontHeightInPoints((short) 12);
	      fontContent.setBoldweight(Font.BOLDWEIGHT_BOLD);
	      fontContent.setFontName("宋体");
	      styleTmep.setFont(fontContent);
          styleTmep.setAlignment(CellStyle.ALIGN_CENTER);
          styleTmep.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
          styleTmep.setBorderTop(CellStyle.BORDER_THIN);
          styleTmep.setBorderRight(CellStyle.BORDER_THIN);
          styleTmep.setBorderBottom(CellStyle.BORDER_THIN);
          styleTmep.setBorderLeft(CellStyle.BORDER_THIN);
          styleTmep.setFillPattern(CellStyle.SOLID_FOREGROUND);
          styleTmep.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
          styleTmep.setWrapText(true);
          styles.put("detailTitle", styleTmep);//  明细第一行标题
          
		 return styles;
	 }
	 
	 public static void main(String arg[]){
		System.out.print("aaaaaa"+"\n"+"ccccc");
	 }
}
