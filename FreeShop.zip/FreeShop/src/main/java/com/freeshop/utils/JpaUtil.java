package com.freeshop.utils;

import java.util.*;

import javax.persistence.*;

public class JpaUtil {

	public static Object singleObjectQuerySql(String sql) {
		EntityTransaction newTx = null;
		EntityManager newEm = null;
		try {
			EntityManagerFactory emf = (EntityManagerFactory) SpringContextUtils
					.getContext().getBean("entityManagerFactory");
			newEm = emf.createEntityManager();
			newTx = newEm.getTransaction();
			newTx.begin();
			Object result = newEm.createNativeQuery(sql).getSingleResult();
			newTx.commit();
			return result;
		} catch (RuntimeException re) {
			if (newTx != null) {
				newTx.rollback();
			}
			throw re;
		} finally {
			if (newEm != null) {
				newEm.close();
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static List listObjectQuerySql(String sql) {
		EntityTransaction newTx = null;
		EntityManager newEm = null;
		try {
			EntityManagerFactory emf = (EntityManagerFactory) SpringContextUtils
					.getContext().getBean("entityManagerFactory");
			newEm = emf.createEntityManager();
			newTx = newEm.getTransaction();
			newTx.begin();
			List result = newEm.createNativeQuery(sql).getResultList();
			newTx.commit();
			return result;
		} catch (RuntimeException re) {
			if (newTx != null) {
				newTx.rollback();
			}
			throw re;
		} finally {
			if (newEm != null) {
				newEm.close();
			}
		}
	}
}
