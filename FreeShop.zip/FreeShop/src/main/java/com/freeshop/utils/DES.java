package com.freeshop.utils;


import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


@SuppressWarnings("restriction")
public class DES {
	static Logger log = LogManager.getLogger(DES.class);
	private final static String encoding = "UTF-8"; 
	
	/**
	 * 加密成字符串
	 * 
	 * @param content
	 *            需要加密的内容
	 * @param encrypt_key
	 *            加密密码 
	 * @return String
	 * */
	public static String encryptString(String content, String encrypt_key) {
		try {
			byte[] encryptResult = encrypt(content, encrypt_key);
		    return ebotongEncrypto(parseByte2HexStr(encryptResult));
		} catch (Exception e) {
			log.error(e.getMessage());
			return content;
		}
	}

	/**
	 * 加密
	 * 
	 * @param content
	 *            需要加密的内容
	 * @param encrypt_key
	 *            加密密码
	 * @return
	 */
	private static byte[] iv = {1,2,3,4,5,6,7,8}; 
	public static byte[] encrypt(String content, String encrypt_key) {
		try {
			IvParameterSpec zeroIv = new IvParameterSpec(iv);  
			SecretKeySpec key = new SecretKeySpec(encrypt_key.getBytes(encoding), "DES"); 
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");// 创建密码器
			byte[] byteContent = content.getBytes(encoding);
			cipher.init(Cipher.ENCRYPT_MODE, key, zeroIv);  
			byte[] result = cipher.doFinal(byteContent);
			return result; // 加密
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return null;
	}

	/**
	 * 解密成字符串 解析不成功返回原密码
	 * 
	 * @param content
	 *            需要解密的内容
	 * @param encrypt_key
	 *            解密密码 
	 * @return String
	 * */
	public static String decryptString(String content, String encrypt_key) {
		String decrpt = ebotongDecrypto(content);
		try {
			byte[] decryptFrom = parseHexStr2Byte(decrpt);
			byte[] decryptResult = decrypt(decryptFrom, encrypt_key);
			if (decryptResult == null) {
				return content;
			}
			return new String(decryptResult);
		} catch (Exception e) {
			log.error(e.getMessage());
			return content;
		}
	}

    public static String decryptStringStrict(String content, String encrypt_key) {
        String decrpt = ebotongDecrypto(content);
        try {
            byte[] decryptFrom = parseHexStr2Byte(decrpt);
            byte[] decryptResult = decrypt(decryptFrom, encrypt_key);
            if (decryptResult == null) {
                return content;
            }
            return new String(decryptResult);
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

	/**
	 * 解密
	 * 
	 * @param content
	 *            待解密内容
	 * @param encrypt_key
	 *            解密密钥
	 * @return
	 */
	public static byte[] decrypt(byte[] content, String encrypt_key) {
		try {
			IvParameterSpec zeroIv = new IvParameterSpec(iv);  
			SecretKeySpec key = new SecretKeySpec(encrypt_key.getBytes(encoding), "DES"); 
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");// 创建密码器
			cipher.init(Cipher.DECRYPT_MODE, key, zeroIv);  
			byte[] result = cipher.doFinal(content);
			return result; // 解密
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return null;
	}

	/**
	 * 将二进制转换成16进制
	 * 
	 * @param buf
	 * @return
	 */
	public static String parseByte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		} 
		return sb.toString();
	}

	/**
	 * 将16进制转换为二进制
	 * 
	 * @param hexStr
	 * @return
	 */
	public static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2),
					16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}

	/**
	 * BASE64加密字符串
	 */
	public static String ebotongEncrypto(String str) {
		BASE64Encoder base64encoder = new BASE64Encoder();
		String result = str;
		if (str != null && str.length() > 0) {
			try {
				byte[] encodeByte = str.getBytes(encoding);
				result = base64encoder.encode(encodeByte);
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		// base64加密超过一定长度会自动换行 需要去除换行符
		return result.replaceAll("\r\n", "").replaceAll("\r", "")
				.replaceAll("\n", "");
	}

	/**
	 * BASE64解密字符串
	 */
	public static String ebotongDecrypto(String str) {
		BASE64Decoder base64decoder = new BASE64Decoder();
		try {
			byte[] encodeByte = base64decoder.decodeBuffer(str);
			return new String(encodeByte);
		} catch (Exception e) {
			log.error(e.getMessage());
			return str;
		}
	}

	public static void main(String[] args) {
		System.out.println(DES.decryptString(AES.decryptString("REM2RDY0OUZFMjk1MDg4MEVCNUE0N0E3NEVERDgwOTc=", "kazhuservicepass"), "bdky1236"));
	}
}
