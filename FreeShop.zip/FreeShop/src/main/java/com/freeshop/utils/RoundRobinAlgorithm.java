package com.freeshop.utils;

import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
@Component("ra")
public class RoundRobinAlgorithm {
		private static Logger logger = LogManager.getLogger(RoundRobinAlgorithm.class);
		@SuppressWarnings("unused")
		private static RoundRobinAlgorithm ra=null;
		private Map<String,Map<String,Double>> circle=null;
		private double countNum=0.0;
		public RoundRobinAlgorithm(){
			Map<String,Double> map=init();
			countNum =countAll(map);
			initCircle(map,countNum);
		}
		
		private Map<String,Double> init(){
			Map<String,Double> map=new HashMap<String,Double>();
			map.put("100",0.1);
			map.put("200",0.15);
			map.put("300",0.3);
			map.put("400",0.15);
			map.put("500",0.1);
			map.put("600",0.06);
			map.put("700",0.05);
			map.put("800",0.04);
			map.put("900",0.03);
			map.put("1000",0.02);
			return map;
		}
		
		private double countAll(Map<String,Double> map){
			double countNum=0.0;
			try{
				Set<Map.Entry<String,Double>> set=map.entrySet();
				for(Map.Entry<String,Double> entry:set){
					countNum+=entry.getValue();
				}
			}catch(Exception e){
				logger.error("初始化面值概率失败");
				countNum=0.0;
			}
			return countNum;
		}
		
		private void initCircle(Map<String,Double> map,double countNum){
			if(map!=null&&!map.isEmpty()&&countNum!=0.0){
				try{
					circle=new HashMap<String,Map<String,Double>>();
					Set<Map.Entry<String,Double>> set=map.entrySet();
					int i=0;
					double max=0.0;
					for(Map.Entry<String,Double> entry:set){
						double val=entry.getValue();
						String key=entry.getKey();
						double d=1/countNum*val;
						if(i==0){
							Map<String,Double> subMap=new HashMap<String,Double>();
							subMap.put("min", 0.0);
							subMap.put("max", d);
							circle.put(key, subMap);
						}else{
							Map<String,Double> subMap=new HashMap<String,Double>();
							subMap.put("min", max);
							subMap.put("max", max+d);
							circle.put(key, subMap);
						}
						max=max+d;
						i++;
					}
				}catch(Exception e){
					
				}
			}else{
				logger.error("获取初始化参数失败,无法生成区间段");
			}
		}
		/**
		 * 优惠券面值抽奖
		 * @param num 领取优惠券的人数
		 * @return key 随机生成的面值
		 * @since 0.1
		 **/
		public String luckDraw(long num){
			try{
				if(circle!=null&&!circle.isEmpty()&&countNum!=0.0){
					if(num==666||num==888){
						return "5000";
					}else if(num==1111){
						return "10000";
					}else{
						double randomNum=Math.random()*countNum;
						Set<Map.Entry<String, Map<String, Double>>> set=circle.entrySet();
						for(Map.Entry<String,Map<String,Double>> entry:set){
							String key=entry.getKey();
							Map<String,Double> val=entry.getValue();
							double min=val.get("min");
							double max=val.get("max");
							if(randomNum>=min&&randomNum<max){
								return key;
							}
						}
					}
				}
			}catch(Exception e){
				logger.error("生成优惠券面值失败!");
			}
			return null;
		}
}
