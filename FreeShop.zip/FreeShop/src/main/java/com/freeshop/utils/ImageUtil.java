package com.freeshop.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ImageUtil {
	static Logger log = LogManager.getLogger(ImageUtil.class);
	
	/**
	 * 获取图片大小 单位为 Byte
	 * */
	public static int getUrlImageLength(String img_url){
		return 0;
	}
	
	public static void main(String[] args) {
		System.out.println(getUrlImageLength("http://m.kayou365.com")/1024);
	}
}
