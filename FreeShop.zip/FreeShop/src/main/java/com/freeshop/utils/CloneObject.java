package com.freeshop.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class CloneObject {
	private static Logger log = LogManager.getLogger(CloneObject.class);
	
	public static Object clone(Object object){
		Object o = null;
		try {
			ByteArrayOutputStream byteOut = new ByteArrayOutputStream(); 
			ObjectOutputStream out = new ObjectOutputStream(byteOut); 
			out.writeObject(object); 
	
			ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray()); 
			ObjectInputStream in =new ObjectInputStream(byteIn); 
		
			o = in.readObject();
		} catch (IOException e) {
			log.error("clone IO",e);
		} catch (ClassNotFoundException e) {
			log.error("clone ClassNotFound",e);
		}
		return o;
	}
}
