package com.freeshop.utils;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EmailUtil {
	protected static final Logger log = LogManager.getLogger(EmailUtil.class);

	public  static void sendEmail(String to, String subject, String content) throws Exception {
		if (Environment.isSendEmail) {
			try {
				HtmlEmail email = new HtmlEmail();
				email.setHostName(PropertiesUtil.readStringValue("email_host"));
				email.setCharset("utf-8");
				if (Environment.DEBUG) {
					log.error("【debug】邮件发送由("+to+")转至("+Environment.DEBUG_EMAIL+")");
					email.addTo(Environment.DEBUG_EMAIL);
				} else {
					email.addTo(to);
				}
				email.setFrom(PropertiesUtil.readStringValue("email_from"));
				email.setAuthentication(PropertiesUtil.readStringValue("email_from"), PropertiesUtil.readStringValue("email_password"));
				email.setSubject(subject);
				email.setHtmlMsg(content);
				email.send();
			} catch (Exception e) {
				log.error("向 "+to+" 发送的 "+subject+" 邮件发送失败了："+e.getMessage(), e);
				throw e;
			}
		} else {
			log.error("【邮件发送功能已关闭】");
		}
	}

	public  static void sendEmailWithAttachment(String to, String subject, String content, EmailAttachment[] attachs) throws EmailException {
		if (Environment.isSendEmail) {
			try {
				HtmlEmail email = new HtmlEmail();
				email.setHostName(PropertiesUtil.readStringValue("email_host"));
				email.setCharset("utf-8");
				if (Environment.DEBUG) {
					log.error("【debug】邮件发送由("+to+")转至("+Environment.DEBUG_EMAIL+")");
					email.addTo(Environment.DEBUG_EMAIL);
				} else {
					email.addTo(to);
				}				
				email.setFrom(PropertiesUtil.readStringValue("email_from"));
				email.setAuthentication(PropertiesUtil.readStringValue("email_from"), PropertiesUtil.readStringValue("email_password"));
				email.setSubject(subject);
				email.setHtmlMsg(content);
				for (int i = 0; i < attachs.length; i++) {
					email.attach(attachs[i]);
				}
				email.send();
			} catch (EmailException e) {
				log.error("向 "+to+" 发送的 "+subject+" 邮件发送失败了："+e.getMessage(), e);
				throw e;
			}

		} else {
			log.error("【邮件发送功能已关闭】");
		}
	}	
}
