package com.freeshop.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;

public class RSA {

	public static final String PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKpevnBdKvLstEC6YCOpEvbqJPXLodI/18++iapiaIoab+ZZzQUwuj+swHxNZPDgyGu977l7/H/TVG759Wj7cWC1WfSTyvCbMOHQVm9zA27N+EljNjuM24uxd4ihaa3f6XfV+NM8kPMyjLRaBccZGXzaP5QkTWI3j0DY8VIcvzk3AgMBAAECgYAf66Z0uRAN+cmAAyt2Ivx5pL8OCnwkP2/47XMvqEZ78Z4bo6GlIk8TFRPvdjS+aO9EOI8Myq0xae/85vpTFCFWtfGhQwmGJOQwhAGSOMowl/IvtUkP1gXjUXsGcb7+trXjP5C5s1Vrvuqc9W9QS94P1AUI++sSQ9GBwAS6puPSiQJBANlfNERSitiYhLDlu7UZnnBWzoMCSRZ3kSDEdwAYDGf/LVRjbQqrrHDO6g9XwBkIQG2jGMOPKpjuJ54BDLoXx+MCQQDIpU8xXo/y9PxRlE6JAwhiE3zDX8SysMHOwjTeesFkzirJOE39CrgFLdqi0m9CpnoHukudXp9irGhRofh2Q0GdAkBj+kzw68Ie0y+cqV2Hc0wTQWnkieWR5taiapqNOYJjRtPTj5N0p/c9P34aJnMdUFVJ2A0ozS17f3ZLTxJKeWufAkEAtwt4b8Wg9TjiZ1oxO3V01GSK0YIw5AO1C3bI3J6Ih/o9tkyTeWGp96+ZYikwL1HIyfv+t5Z3OYGnubFWBi3dUQJAbi+6uGv52uef3k9HXIgsv89MG8UlM4+IV2q7GpvZIzxKM5t92/Xbs3nOtpu/HALn1IcaUDoySvjZ8gZTfvWu0Q==";
	public static final String PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCqXr5wXSry7LRAumAjqRL26iT1y6HSP9fPvomqYmiKGm/mWc0FMLo/rMB8TWTw4Mhrve+5e/x/01Ru+fVo+3FgtVn0k8rwmzDh0FZvcwNuzfhJYzY7jNuLsXeIoWmt3+l31fjTPJDzMoy0WgXHGRl82j+UJE1iN49A2PFSHL85NwIDAQAB";
	public static final String input_charset = "utf-8";

	/**
	 * 解密
	 * 
	 * @param content
	 *            密文
	 * @param private_key
	 *            商户私钥
	 * @param input_charset
	 *            编码格式
	 * @return 解密后的字符串
	 */
	public static String decrypt(String content) throws Exception {
		PrivateKey prikey = getPrivateKey(PRIVATE_KEY);

		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, prikey);

		InputStream ins = new ByteArrayInputStream(Base64.decode(content));
		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		// rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
		byte[] buf = new byte[128];
		int bufl;

		while ((bufl = ins.read(buf)) != -1) {
			byte[] block = null;

			if (buf.length == bufl) {
				block = buf;
			} else {
				block = new byte[bufl];
				for (int i = 0; i < bufl; i++) {
					block[i] = buf[i];
				}
			}

			writer.write(cipher.doFinal(block));
		}

		return new String(writer.toByteArray(), input_charset);
	}

	/**
	 * 得到私钥
	 * 
	 * @param key
	 *            密钥字符串（经过base64编码）
	 * @throws Exception
	 */
	public static PrivateKey getPrivateKey(String key) throws Exception {

		byte[] keyBytes;

		keyBytes = Base64.decode(key);

		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

		return privateKey;
	}

	/**
	 * 用于微信登录拦截器对密码的处理（缓存）
	 * 
	 * @param loginRequests
	 * @param username
	 * @return
	 */
	public static Map<String, Map<String, Object>> handleLoginRequest(Map<String, Map<String, Object>> loginRequests,
			String username) {

		Long cur_time = System.currentTimeMillis() / 1000;

		if (loginRequests.containsKey(username)) {

			Long first_time = Long.parseLong(loginRequests.get(username).get("first_time").toString());

			long ret = cur_time - first_time;
			int counts = Integer.parseInt(loginRequests.get(username).get("counts").toString());

			if (ret < 10 * 60 && counts < 3) {
				// 10min之内小于3次
				loginRequests.get(username).put("counts", counts + 1);
				loginRequests.get(username).put("if_can_go_on", true);
			} else if (ret < 10 * 60 && counts >= 3) {
				// 10min之内已达3次
				loginRequests.get(username).put("if_can_go_on", false);
			} else if (ret > 10 * 60) {
				// 超过10min，重置
				loginRequests.get(username).put("first_time", System.currentTimeMillis() / 1000);
				loginRequests.get(username).put("counts", 1);
				loginRequests.get(username).put("if_can_go_on", true);
			}
		} else {
			Map<String, Object> inner = new HashMap<>();
			inner.put("first_time", System.currentTimeMillis() / 1000);
			inner.put("counts", 1);
			inner.put("if_can_go_on", true);
			loginRequests.put(username, inner);
		}
		return loginRequests;
	}

	public static void main(String[] args) throws Exception {

		System.out.println(decrypt("cTQ/B72VsKRfiAWC9skbZrXQh4WdbF6mQTIyYNuRhXahQ7gsIod9vP3KsGPsspkCUXOVXad30EwzSaiu2TFioM5Dx189M+d8MxaJHmoySPybnQ058XI1WHKZduITTXQXZOCKISIyFjX2C0FNKMakZk4En58IP6o6kSudFbq7tgg="));
	}

}