package com.freeshop.utils;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;


public class SortUtil {
	public static final String ASC = "ASC"; 
	public static final String DESC = "DESC";
	
	public static <T> void sortList(List<T> list,String order,String rank_method){
		Collections.sort(list, new CustomComparator<T>(order,rank_method));
	}
}
class CustomComparator<T> implements Comparator<T>{
	
	private String order;
	private String rank_method;
	private Map<Integer,String[]> colOrderMap;//map.put(0,new String[]{"rank1",CustomComparator.ASC});
	public static final String ASC = SortUtil.ASC; 
	public static final String DESC = SortUtil.DESC;
	
	
	public CustomComparator(String order, String rank_method) {
		super();
		this.order = order;
		this.rank_method = rank_method;
	}
	
	public CustomComparator(Map<Integer,String[]> colOrderMap) {
		super();
		this.colOrderMap = colOrderMap;
	}
	
	@Override
	public int compare(T o1, T o2) {
		if(colOrderMap!=null){
			for(int i=0;i<colOrderMap.size();i++){
				String[] ss = colOrderMap.get(i);
				String col = ss[0];
				String ord = ss[1];
				int v = compare(o1,o2,col,ord);
				if(v==0){
					continue;
				}
				return v;
			}
			return 0;
		}else{
			return compare(o1,o2,rank_method,order);
		}
	}
	
	private int compare(T o1, T o2,String rank_method,String order){
		//String col = StringUtils.indexToUpcase(column);
		Class<? extends Object> c = o2.getClass();
		switch (order) {
		case ASC:
			try {
//				Method m = c.getMethod("get"+col);
				Method m = c.getMethod(rank_method);
				Object oo1 = m.invoke(o1);
				Object oo2 = m.invoke(o2);
				if(oo1 instanceof Integer){
					Integer i1 = (Integer)oo1;
					Integer i2 = (Integer)oo2;
					return i1.compareTo(i2);
				}
				if(oo1 instanceof Long){
					Long i1 = (Long)oo1;
					Long i2 = (Long)oo2;
					return i1.compareTo(i2);
				}
				if(oo1 instanceof String){
					String i1 = (String)oo1;
					String i2 = (String)oo2;
					return i1.compareTo(i2);
				}
			} catch (Exception e) {
			} 
			return 0;
			
		case DESC:
			try {
				Method m = c.getMethod(rank_method);
				Object oo1 = m.invoke(o1);
				Object oo2 = m.invoke(o2);
				if(oo1 instanceof Integer){
					Integer i1 = (Integer)oo1;
					Integer i2 = (Integer)oo2;
					return i2.compareTo(i1);
				}
				if(oo1 instanceof Long){
					Long i1 = (Long)oo1;
					Long i2 = (Long)oo2;
					return i2.compareTo(i1);
				}
				if(oo1 instanceof String){
					String i1 = (String)oo1;
					String i2 = (String)oo2;
					return i2.compareTo(i1);
				}
			} catch (Exception e) {
			} 
			return 0;
		}
		return 0;
	}
}
