package com.freeshop.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;


public class ReadWriteFile {
	@SuppressWarnings("unused")
	public static Map<String,String> readByLine(String fileName) throws Exception{
		Map<String,String> map = new HashMap<String,String>();
		File file = new File(fileName);

		InputStreamReader read = new InputStreamReader(new FileInputStream(file),"UTF-8"); 
		BufferedReader reader = new BufferedReader(read);

		try {
			String tempString = null;
			int line = 1;
			while ((tempString = reader.readLine()) != null) {
				String[] arr = tempString.split(",");
				if(arr.length==2){
					map.put(arr[0], arr[1]);
				}
				line++;
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
		return map;
		
	}
//	public static void main(String s[]) throws Exception{
//		String fileName = "D:/KaZhuService/src/main/resources/BrandIdOrm.txt";
//		Map<String,String> map = ReadWriteFile.readByLine(fileName);
//		for(String key : map.keySet()){
//			System.out.println(key.trim()+" "+map.get(key));
//		}
//	}
}
