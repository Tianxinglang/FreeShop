/**
 * 
 */
package com.freeshop.utils;

/**
 * 读取配置
 */
public class Environment {
	public static final boolean isSendEmail = Boolean.parseBoolean(PropertiesUtil.readStringValue("isSendEmail"));
	public static final boolean isSendSMS = Boolean.parseBoolean(PropertiesUtil.readStringValue("isSendSMS"));
	public static final boolean DEBUG = Boolean.parseBoolean(PropertiesUtil.readStringValue("debug"));
	public static final String DEBUG_EMAIL =PropertiesUtil.readStringValue("debug_email");
	public static final String DEBUG_MOBILE = PropertiesUtil.readStringValue("debug_mobile");
}
