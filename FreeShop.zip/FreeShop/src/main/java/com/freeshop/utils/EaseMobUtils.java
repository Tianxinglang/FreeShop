package com.freeshop.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import net.sf.json.JSONObject;

public class EaseMobUtils {
	public static final String DEFAULT_CHARSET = "UTF-8";
	private static final String METHOD_POST = "POST";
	private static final String METHOD_DELETE = "DELETE";
	private static final String METHOD_GET = "GET";
	public static final int connectTimeout = 60000;//60秒
	public static final int readTimeout = 60000;//60秒
	public static final String TOKEN_URL="https://a1.easemob.com/cardqu/kaqu/token";
	public static final String TOKEN_PARAMS="{\"grant_type\": \"client_credentials\",\"client_id\": \"YXA6hhxtMGZoEeWVY6vJ5cZUbQ\",\"client_secret\": \"YXA6ZLWTKP5JBj5fNdHZ7FOyqschhM0\"}";
	public static final String MESSAGE_URL="https://a1.easemob.com/cardqu/kaqu/messages";
	/**
	 * 环信即时聊天获取token(post请求)
	 * @throws IOException 
	 */
	public static  String doEasemobPostToken() throws IOException{
		System.out.println("开始获取环信token");
		HttpURLConnection conn=null;
		String rsp = null;
		OutputStreamWriter out=null;
		try {
		    URL url = new URL(TOKEN_URL); 
		    conn = (HttpURLConnection)url.openConnection();  
		    conn.setDoInput(true);
		    conn.setDoOutput(true);
		    conn.setUseCaches(false);  
		    conn.setInstanceFollowRedirects(true); 
		    conn.setRequestMethod(METHOD_POST);
		    conn.setRequestProperty("Content-Type", "application/json");
		    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
		    conn.connect();  
		    out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
		    out.append(TOKEN_PARAMS);  
		    out.flush();  
		    System.out.println("===开始接受返回数据====");  
		    rsp=getResponseAsString(conn); 
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (conn != null) {
				conn.disconnect();
			}
			if(out !=null){
				out.close();
			}
		}
		return rsp;
	}
	/**
	 * 环信即时聊天获取聊天记录(get请求)
	 * @throws IOException 
	 */
	public static  String doEasemobGetMessages(String urlStr,String token) throws IOException{
		System.out.println("开始获取环信聊天记录");
		HttpURLConnection conn=null;
		String rsp = null;
		try {
		    URL url = new URL(urlStr); 
		    conn = (HttpURLConnection)url.openConnection();  
		    conn.setDoInput(true);
		    conn.setDoOutput(true);
		    conn.setUseCaches(false);  
		    conn.setInstanceFollowRedirects(true); 
		    conn.setRequestMethod(METHOD_GET);
		    conn.setRequestProperty("Content-Type", "application/json");
		    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
		    conn.setRequestProperty("Authorization","Bearer "+token);
		    conn.connect();  
		    System.out.println("===开始接受返回的聊天记录数据====");  
		    rsp=getResponseAsString(conn); 
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (conn != null) {
				conn.disconnect();
			}
		}
		return rsp;
	}
	/**
	 * 发送环信消息
	 * @param token
	 * @throws IOException 
	 */
	@SuppressWarnings("unused")
	public static void sendMessages(String token,String msg,String fromname,String toname) throws IOException{
		System.out.println("开始发送消息");
		HttpURLConnection conn=null;
		String rsp = null;
		OutputStreamWriter out=null;
		URL url = new URL(MESSAGE_URL); 
	    conn = (HttpURLConnection)url.openConnection();  
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setUseCaches(false);  
	    conn.setInstanceFollowRedirects(true); 
	    conn.setRequestMethod(METHOD_POST);
	    conn.setRequestProperty("Content-Type", "application/json");
	    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
	    conn.setRequestProperty("Authorization","Bearer "+token);
	    conn.connect();
	    out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
	    //设置参数
	    JSONObject json=new JSONObject();
	    JSONObject j=new JSONObject();
	    String[] users=new String[]{toname};
	    j.put("type","txt");
	    j.put("msg",msg);
	    json.put("target_type", "users");
	    json.put("target", users);
	    json.put("msg", j);
	    json.put("from", fromname);
	    out.append(json.toString());
	    out.flush();  
	    rsp=getResponseAsString(conn); 
	}
	/**
	 * 发送环信拓展消息消息
	 * @param token
	 * @throws IOException 
	 */
	@SuppressWarnings("unused")
	public static void sendExpandMessages(String token,String msg,String fromname,String toname,String attr,String context) throws IOException{
		System.out.println("开始发送拓展消息");
		HttpURLConnection conn=null;
		String rsp = null;
		OutputStreamWriter out=null;
		URL url = new URL(MESSAGE_URL); 
	    conn = (HttpURLConnection)url.openConnection();  
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setUseCaches(false);  
	    conn.setInstanceFollowRedirects(true); 
	    conn.setRequestMethod(METHOD_POST);
	    conn.setRequestProperty("Content-Type", "application/json");
	    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
	    conn.setRequestProperty("Authorization","Bearer "+token);
	    conn.connect();
	    out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
	    //设置参数
	    JSONObject json=new JSONObject();
	    JSONObject j=new JSONObject();
	    String[] users=new String[]{toname};
	    if("".equals(msg)){
	    	 j.put("type","txt");
	 	     j.put("msg",msg);
	    }
	    json.put("target_type", "users");
	    json.put("target", users);
	    json.put("msg", j);
	    json.put("from", fromname);
	    JSONObject c=new JSONObject();
	    c.put(attr,context);
	    json.put("ext", c);
	    out.append(json.toString());
	    out.flush();  
	    rsp=getResponseAsString(conn); 
	}
	/**
	 * 开始加入黑名单
	 * @param token
	 * @throws IOException 
	 */
	@SuppressWarnings("unused")
	public static void deFriendsHuanxin(String token,String fromname,String toname) throws IOException{
		System.out.println("开始加入黑名单");
		HttpURLConnection conn=null;
		String rsp = null;
		OutputStreamWriter out=null;
		URL url = new URL("https://a1.easemob.com/cardqu/kaqu/users/"+fromname+"/blocks/users"); 
	    conn = (HttpURLConnection)url.openConnection();  
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setUseCaches(false);  
	    conn.setInstanceFollowRedirects(true); 
	    conn.setRequestMethod(METHOD_POST);
	    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
	    conn.setRequestProperty("Authorization","Bearer "+token);
	    conn.connect();
	    out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
	    //设置参数
	    JSONObject json=new JSONObject();
	    String[] users=new String[]{toname};
	    json.put("usernames", users);
	    out.append(json.toString());
	    out.flush();  
	    rsp=getResponseAsString(conn); 
	}
	/**
	 * 移出黑名单
	 * @param token
	 * @throws IOException 
	 */
	@SuppressWarnings("unused")
	public static void removeBlackList(String token,String fromname,String toname) throws IOException{
		System.out.println("开始移出黑名单");
		HttpURLConnection conn=null;
		String rsp = null;
		URL url = new URL("https://a1.easemob.com/cardqu/kaqu/users/"+fromname+"/blocks/users/"+toname); 
	    conn = (HttpURLConnection)url.openConnection();  
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setUseCaches(false);  
	    conn.setInstanceFollowRedirects(true); 
	    conn.setRequestMethod(METHOD_DELETE);
	    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
	    conn.setRequestProperty("Authorization","Bearer "+token);
	    conn.connect();
	    rsp=getResponseAsString(conn); 
	}
	/**
	 * 获取黑名单
	 * @param token
	 * @throws IOException 
	 */
	public static String getBlackList(String token,String fromname) throws IOException{
		System.out.println("开始获取黑名单");
		HttpURLConnection conn=null;
		String rsp = null;
		URL url = new URL("https://a1.easemob.com/cardqu/kaqu/users/"+fromname+"/blocks/users"); 
	    conn = (HttpURLConnection)url.openConnection();  
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setUseCaches(false);  
	    conn.setInstanceFollowRedirects(true); 
	    conn.setRequestMethod(METHOD_GET);
	    conn.setRequestProperty("Accept-Charset", DEFAULT_CHARSET);
	    conn.setRequestProperty("Authorization","Bearer "+token);
	    conn.connect();
	    rsp=getResponseAsString(conn); 
	    return rsp;
	}
	protected static String getResponseAsString(HttpURLConnection conn) throws IOException {
		String charset = getResponseCharset(conn.getContentType());
		InputStream es = conn.getErrorStream();
		if (es == null) {
			return getStreamAsString(conn.getInputStream(), charset);
		} else {
			String msg = getStreamAsString(es, charset);
			if (StringUtils.isEmpty(msg)) {
				throw new IOException(conn.getResponseCode() + ":" + conn.getResponseMessage());
			} else {
				throw new IOException(msg);
			}
		}
	}

	private static String getStreamAsString(InputStream stream, String charset) throws IOException {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(stream, charset));
			StringWriter writer = new StringWriter();

			char[] chars = new char[256];
			int count = 0;
			while ((count = reader.read(chars)) > 0) {
				writer.write(chars, 0, count);
			}

			return writer.toString();
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}
	private static String getResponseCharset(String ctype) {
		String charset = DEFAULT_CHARSET;

		if (!StringUtils.isEmpty(ctype)) {
			String[] params = ctype.split(";");
			for (String param : params) {
				param = param.trim();
				if (param.startsWith("charset")) {
					String[] pair = param.split("=", 2);
					if (pair.length == 2) {
						if (!StringUtils.isEmpty(pair[1])) {
							charset = pair[1].trim();
						}
					}
					break;
				}
			}
		}

		return charset;
	}
}
