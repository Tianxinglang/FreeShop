package com.freeshop.utils;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class PropertiesUtil {
	private static InputStream in;
	private static InputStream filePath = PropertiesUtil.class.getClassLoader().getResourceAsStream("application.properties");
	//private static InputStream filePath;
	
	
	private static Properties props;
	static {
		/*try {
			filePath = new FileInputStream("D:\\workspace\\KaZhuService\\src\\main\\resources\\application.properties");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		props = new Properties();
		try {
			in = new BufferedInputStream(filePath);
			props.load(in);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public static String readStringValue(String key){
		return props.getProperty(key);
	}
	
	public static int readIntValue(String key){
		return Integer.parseInt(props.getProperty(key));
	}
	
	public static String[] readStringArray(String key, String regex){
		String val = props.getProperty(key);
		String[] result = val.split(regex);
		return result;
	}
}
