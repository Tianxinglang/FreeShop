package com.freeshop.utils;


import java.io.*;
import java.util.HashMap;

//import com.bcloud.msg.http.HttpSender;
import com.bcloud.msg.http.HttpSender;
import com.freeshop.utils.PropertiesUtil;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;

public class SMSUtil {

	private static  final String cl_SMS_URL= PropertiesUtil.readStringValue("cl_sms_url");
	private static  final String cl_username=PropertiesUtil.readStringValue("cl_username");
	private static  final String cl_password=PropertiesUtil.readStringValue("cl_password");

	private static  final String yt_SMS_URL=PropertiesUtil.readStringValue("yt_sms_url");
	private static  final String yt_username=PropertiesUtil.readStringValue("yt_username");
	private static  final String yt_password=PropertiesUtil.readStringValue("yt_password");

	private static  final String GatewaySelection=PropertiesUtil.readStringValue("gateway");


	@SuppressWarnings("unused")
	private static int sendSMS_yt(String mobile, String sms) throws Exception {
		String command = "MT_REQUEST";

		String spsc = "00";
		String sa = "";
		String da = "86" + mobile;
		int dc = 15;
		String ecodeform = "GBK";
		String sm = new String(Hex.encodeHex(sms.getBytes(ecodeform)));

		StringBuilder smsUrl = new StringBuilder();
		smsUrl.append(yt_SMS_URL);
		smsUrl.append("?command=" + command);
		smsUrl.append("&spid=" + yt_username);
		smsUrl.append("&sppassword=" + yt_password);
		smsUrl.append("&spsc=" + spsc);
		smsUrl.append("&sa=" + sa);
		smsUrl.append("&da=" + da);
		smsUrl.append("&sm=" + sm);
		smsUrl.append("&dc=" + dc);

		String resStr = doGetRequest(smsUrl.toString());

		//System.out.println(smsUrl.toString());

//        HashMap<String,String> pp = parseResStr(resStr);
//        System.out.println(pp.get("command"));
//        System.out.println(pp.get("spid"));
//        System.out.println(pp.get("mtmsgid"));
//        System.out.println(pp.get("mtstat"));
//        System.out.println(pp.get("mterrcode"));
		  return 0;
	}

	private static int sendSMS_cl(String mobile, String sms) throws Exception {
		String uri = cl_SMS_URL;//应用地址
		String account = cl_username;//账号
		String pswd = cl_password;//密码
		String mobiles = mobile;//手机号码，多个号码使用","分割
		String content = sms;//短信内容
		boolean needstatus = true;//是否需要状态报告，需要true，不需要false
		String product = null;//产品ID
		String extno = null;//扩展码

		try {
			String returnString = HttpSender.batchSend(uri, account, pswd, mobiles, content, needstatus, product, extno);
			System.out.println(returnString);
			//TODO 处理返回值,参见HTTP协议文档
		} catch (Exception e) {
			//TODO 处理异常
			e.printStackTrace();
		}
		return 0;
	}

	public  static int sendSMS(String mobile, String sms) throws Exception {
		int ret = 0;
		switch (GatewaySelection) {
			case "cl" : ret = sendSMS_cl(mobile, sms); break;
			//case "yt" : ret = sendSMS_yt(mobile,sms);break;
			default: ret = sendSMS_cl(mobile,sms);
		}
		return ret;
	}

	public static void main(String[] args) throws Exception {

		sendSMS_cl("18616369400", "您卡趣账户中的85度C经典咖啡兑换券将于10月31日到期，请及时去活动指定门店兑换和使用哈！");
	}

	private static String doGetRequest(String urlstr) {
		String res = null;
		org.apache.commons.httpclient.HttpClient client = new org.apache.commons.httpclient.HttpClient(new MultiThreadedHttpConnectionManager());
		client.getParams().setIntParameter("http.socket.timeout", 10000);
		client.getParams().setIntParameter("http.connection.timeout", 5000);

		HttpMethod httpmethod = new GetMethod(urlstr);
		try {
			int statusCode = client.executeMethod(httpmethod);
			if (statusCode == HttpStatus.SC_OK) {
				res = httpmethod.getResponseBodyAsString();
			}
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			httpmethod.releaseConnection();
		}
		return res;
	}

	@SuppressWarnings("unused")
	private static HashMap<String,String> parseResStr(String resStr) {
		HashMap<String,String> pp = new HashMap<String,String>();
		try {
			String[] ps = resStr.split("&");
			for(int i=0;i<ps.length;i++){
				int ix = ps[i].indexOf("=");
				if(ix!=-1){
					pp.put(ps[i].substring(0,ix),ps[i].substring(ix+1));
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return pp;
	}
}
