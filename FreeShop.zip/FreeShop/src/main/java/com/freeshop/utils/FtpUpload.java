package com.freeshop.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.net.ftp.FTPClient;    
import org.apache.commons.net.ftp.FTPReply;   
import org.springframework.web.multipart.MultipartFile;

import com.freeshop.config.FreeShopPropertyPlaceholderConfigurer;

public class FtpUpload {

//	private  static FTPClient ftp; 
//	private static String server_image_directory = (String)BingdianPropertyPlaceholderConfigurer.getContextProperty("server_image_directory");
//	private static String server_image_address = (String)BingdianPropertyPlaceholderConfigurer.getContextProperty("server_image_address");
	private static String server_image_username = (String)FreeShopPropertyPlaceholderConfigurer.getContextProperty("server_image_username");
	private static String server_image_password = (String)FreeShopPropertyPlaceholderConfigurer.getContextProperty("server_image_password");
	private static String temporary_image_directory = (String)FreeShopPropertyPlaceholderConfigurer.getContextProperty("temporary_image_directory");
	
	/**  
     *   
     * @param path 上传到ftp服务器哪个路径下     
     * @param addr 地址  
     * @param port 端口号  
     * @param username 用户名  
     * @param password 密码  
     * @return  
     * @throws Exception  
     */    
	private static boolean connect(String path,String addr,int port,String username,String password,FTPClient ftp) throws Exception {      
        boolean result = false;      
//        ftp = new FTPClient();
       
        //ftp.enterLocalActiveMode();
        
        int reply;      
        ftp.connect(addr,port);      
        ftp.login(username,password);      
        ftp.setFileType(FTPClient.BINARY_FILE_TYPE);      
        reply = ftp.getReplyCode();      
        if (!FTPReply.isPositiveCompletion(reply)) {      
            ftp.disconnect();      
            return result;      
        }      
        ftp.changeWorkingDirectory(path);      
        result = true;      
        return result;      
    }
	
	 /**  
     *   
     * @param file 上传的文件或文件夹  
     * @throws Exception  
     */    
    private static void upload(File file,FTPClient ftp) throws Exception{      
        if(file.isDirectory()){           
            ftp.makeDirectory(file.getName());                
            ftp.changeWorkingDirectory(file.getName());      
            String[] files = file.list();             
            for (int i = 0; i < files.length; i++) {      
                File file1 = new File(file.getPath()+"\\"+files[i] );      
                if(file1.isDirectory()){      
                    upload(file1,ftp);      
                    ftp.changeToParentDirectory();      
                }else{                    
                    File file2 = new File(file.getPath()+"\\"+files[i]);      
                    FileInputStream input = new FileInputStream(file2);      
                    ftp.storeFile(file2.getName(), input);      
                    input.close();                            
                }                 
            }      
        }else{  
        	ftp.enterLocalPassiveMode();
            File file2 = new File(file.getPath());      
            FileInputStream input = new FileInputStream(file2);      
            ftp.storeFile(file2.getName(), input);      
            input.close();        
        }      
        
        if (ftp.isConnected()) {  
            try  {  
                ftp.disconnect();  
            } catch  (IOException ioe) {  
            }  
        }   
    }      
    
   /**
    * 上传文件
 * @throws Exception 
    */
    public static String uploadFiles(MultipartFile multipartFile,String server_image_directory,String server_image_address) throws Exception{
    	try {
    		FTPClient ftp = new FTPClient();
    		String realPath = temporary_image_directory;
    		String filename = multipartFile.getOriginalFilename();
    		filename = filename.substring(0,filename.indexOf("."))+"_"+System.currentTimeMillis();
    		System.out.println("filename = "+filename);
    		File targetFile=new File(new File(realPath),filename+".jpg");
    		if(!targetFile.exists())
    		{
    			targetFile.createNewFile(); 
    			System.out.println("create new file");
    		}
			multipartFile.transferTo(targetFile);
			connect(server_image_directory, server_image_address, 21, server_image_username, server_image_password,ftp);
			upload(targetFile,ftp);
			targetFile.delete();
    		System.out.println("上传完成 返回url = "+(server_image_directory.substring(1)+"/"+filename+".jpg"));
    		return server_image_directory.substring(1)+"/"+filename+".jpg";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
    	
    }
}

