package com.freeshop;
//package com.bingdian;
//
//import com.bingdian.repository.UsrTokenRepository;
//import junit.framework.TestCase;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.web.WebAppConfiguration;
//
//import javax.persistence.EntityManagerFactory;
//
///**
// * Created by zhawei on 14-3-18.
// */
//@RunWith(SpringJUnit4ClassRunner.class)
//@WebAppConfiguration
//@ContextConfiguration("file:src/main/webapp/WEB-INF/mvc-dispatcher-servlet.xml")
//public class SecurityServiceImplTest {
//    Logger log = LogManager.getLogger(SecurityServiceImplTest.class);
//    @Autowired
//    UsrTokenRepository securityService;
//
//    @Test
//    public void testValidUser() throws Exception {
//        log.info(securityService.validByToken("2.00zII3JBmsh_PE6f45eed4d0eZF8JD"));
//    }
//
//    @Test
//    public void testFindUser() throws Exception {
//        log.info(securityService.getByToken("2.00zII3JBmsh_PE6f45eed4d0eZF8JD"));
//    }
//
//}
