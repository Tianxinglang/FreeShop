package com.freeshop;

import org.junit.Test;

import com.freeshop.utils.SMSUtil;
public class SMSUtilTest {

	@Test//发送短信
	public void testSendSMS() {
		try {
			SMSUtil.sendSMS("15026745264", "内容哈哈哈哈测试测试");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		try {
			SMSUtil.sendSMS("15026745264", "内容哈哈哈哈");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
