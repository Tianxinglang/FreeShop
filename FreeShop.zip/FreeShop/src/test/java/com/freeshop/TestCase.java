package com.freeshop;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.freeshop.utils.SignUtils;

public class TestCase {
    @Test
    public void test(){
        Map<String,String> map=new HashMap<String,String>();
        map.put("login_id","201508171300234475990");
        map.put("timestamp","1439788043");
        map.put("coupon_id","1000000104");
        map.put("login_version","android_1.7");
        map.put("project_type","kaqu");
        map.put("appSecret","4iT0UCL0BQTS7XN9YC04B2YkV2F4K3");
        System.out.println(SignUtils.sign(map));
        //System.out.println(gen(30));
    }




    public static String gen(int length) {
        char[] ss = new char[length];
        int i=0;
        while(i<length) {
            int f = (int) (Math.random()*3);
            if(f==0)
                ss[i] = (char) ('A'+Math.random()*26);
            else if(f==1)
                ss[i] = (char) ('a'+Math.random()*26);
            else
                ss[i] = (char) ('0'+Math.random()*10);
            i++;
        }
        String is=new String(ss);
        return is;
    }

}
