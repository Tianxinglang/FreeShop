package com.freeshop;

import org.apache.commons.mail.EmailAttachment;
import org.junit.Test;

import com.freeshop.utils.EmailUtil;

public class EmailUtilTest {

	@Test//发送普通邮件
	public void testEmail() {
		try {
			EmailUtil.sendEmail("zhangshuzhen@bingdian.com", "主题", "普通邮件内容内容内容++++----");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test//发送带附件的邮件
	public void testEmailWithAttachment() {
		try {
			EmailAttachment[] attachs= new EmailAttachment[1];
			EmailAttachment attach = new EmailAttachment();
			attach.setPath("d:/f1.doc");
			attach.setName("abc.doc");
			attachs[0]=attach;
			EmailUtil.sendEmailWithAttachment("zhangshuzhen@bingdian.com", "主题", "带附件的邮件内容内容内容",attachs);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		try {
			EmailUtil.sendEmail("zhangshuzhen@bingdian.com", "主题", "普通邮件内容内容内容");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
