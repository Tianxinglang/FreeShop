package com.freeshop;
//package com.bingdian;
//
//import com.bingdian.domain.table.T_Wp_Usermeta;
//import com.bingdian.repository.TestRepository;
//
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.web.WebAppConfiguration;
//
//import javax.persistence.EntityManagerFactory;
//
///**
// * Created by zhawei on 14-3-18.
// */
//@RunWith(SpringJUnit4ClassRunner.class)
//@WebAppConfiguration
//@ContextConfiguration("file:src/main/webapp/WEB-INF/mvc-dispatcher-servlet.xml")
//public class JpaTest {
//
//    @Autowired
//    private EntityManagerFactory entityManagerFactory;
//
//    @Autowired
//    private TestRepository testRepository;
//
//    @BeforeClass
//    public static void beforeClass() {
//
//    }
//
//    @Test
//    public void testJpa(){
//         System.out.println(entityManagerFactory.toString());
//    }
//
//    @Test
//    public void testfindOne(){
//        T_Wp_Usermeta test = testRepository.findOne(3);
//        org.junit.Assert.assertTrue(test.getMeta_key().equalsIgnoreCase("nickname"));
//        System.out.println( test );
//    }
//}
